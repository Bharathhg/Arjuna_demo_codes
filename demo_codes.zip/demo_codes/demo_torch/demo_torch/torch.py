#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from std_msgs.msg import Int8
from rcl_interfaces.msg import SetParametersResult
import smbus2

class TorchControlNode(Node):
    def __init__(self):
        super().__init__('Torch_control')
        
        # Declare ROS 2 parameters
        self.declare_parameter('torch_on_value', 1)
        self.declare_parameter('torch_off_value', 2)
        self.declare_parameter('led_state', 2)

        self.torch_on_value = self.get_parameter('torch_on_value').get_parameter_value().integer_value
        self.torch_off_value = self.get_parameter('torch_off_value').get_parameter_value().integer_value
        initial_state = self.get_parameter('led_state').get_parameter_value().integer_value
        self.torch_data = self.get_actual_value(initial_state)

        # Register parameter callback for dynamic updates
        self.add_on_set_parameters_callback(self.parameter_callback)
        
        # ROS 2 subscription to the "Torch" topic
        self.subscription = self.create_subscription(
            Int8,
            'Torch',
            self.callback,
            10
        )
        
        # Setup smbus2 for I2C communication with Arduino
        # I2C channel (usually 1 on Jetson Nano)
        # Arduino Nano I2C address is 0x08
        self.arduino_address = 0x08
        try:
            self.bus = smbus2.SMBus(1)
            self.i2c_available = True
            self.get_logger().info("I2C Bus 1 successfully initialized.")
        except Exception as e:
            self.get_logger().error(f"Failed to initialize I2C Bus: {e}. Running in Mock mode.")
            self.i2c_available = False

        # Run process loop every 0.1s (10Hz) using a ROS 2 Timer
        self.timer = self.create_timer(0.1, self.process)
        self.get_logger().info(f"Torch control node has started. Initial state: {initial_state} (I2C byte: {self.torch_data})")

    def get_actual_value(self, state):
        if state == 1:
            return self.torch_on_value
        elif state == 0:
            return self.torch_off_value
        return state

    def parameter_callback(self, params):
        for param in params:
            if param.name == 'led_state':
                self.torch_data = self.get_actual_value(param.value)
                self.get_logger().info(f"Parameter led_state changed to: {param.value} -> Actual I2C byte: {self.torch_data}")
            elif param.name == 'torch_on_value':
                self.torch_on_value = param.value
                self.get_logger().info(f"Parameter torch_on_value updated to: {self.torch_on_value}")
            elif param.name == 'torch_off_value':
                self.torch_off_value = param.value
                self.get_logger().info(f"Parameter torch_off_value updated to: {self.torch_off_value}")
        return SetParametersResult(successful=True)

    def callback(self, msg):
        cmd = msg.data
        self.torch_data = self.get_actual_value(cmd)
        self.get_logger().info(f"Received Topic command: {cmd} -> Actual I2C byte: {self.torch_data}")

    def process(self):
        if self.i2c_available:
            try:
                self.bus.write_byte(self.arduino_address, self.torch_data)
                self.get_logger().debug(f"Data sent to Arduino: {self.torch_data}")
            except Exception as e:
                self.get_logger().error(f"I2C write error to Arduino: {e}")
        else:
            self.get_logger().debug(f"[MOCK] Data sent to Arduino: {self.torch_data}")

def main(args=None):
    rclpy.init(args=args)
    node = TorchControlNode()
    
    # Spin ROS 2 in a background thread to handle callbacks and parameters
    import threading
    spin_thread = threading.Thread(target=rclpy.spin, args=(node,), daemon=True)
    spin_thread.start()

    print("\n" + "="*50)
    print(" Interactive LED / Torch Control Terminal")
    print("="*50)
    print("Commands:")
    print("  on  - Turn LED ON")
    print("  off - Turn LED OFF")
    print("  exit - Exit the node")
    print("="*50 + "\n")

    try:
        while rclpy.ok():
            user_input = input("Enter command (on/off): ").strip().lower()
            if user_input == 'exit':
                break
            elif user_input in ['on', 'ona']:
                node.torch_data = node.torch_on_value
                print(f"--> LED turned ON (I2C byte sent: {node.torch_data})")
            elif user_input == 'off':
                node.torch_data = node.torch_off_value
                print(f"--> LED turned OFF (I2C byte sent: {node.torch_data})")
            elif user_input == '':
                continue
            else:
                print("Unknown command. Please enter 'on' or 'off'.")
    except (KeyboardInterrupt, EOFError):
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
