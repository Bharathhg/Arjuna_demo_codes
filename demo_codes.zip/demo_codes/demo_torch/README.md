# demo_torch — Torch / LED Control via I²C (Arduino Bridge)

Demonstrates how to control an **Arduino-connected torch/LED** from ROS 2 using **I²C communication** via `smbus2`. The ROS node subscribes to a command topic and forwards the command to an Arduino Nano acting as an I²C slave.

## 🔑 Concept

> Not all hardware can be driven directly from a Linux SBC (Jetson/Raspberry Pi). A common pattern is to use an **Arduino Nano as an I²C slave** to handle real-time hardware control (LEDs, relays, servos, etc.), while the ROS 2 node acts as the I²C master sending commands over the bus.

```
ROS 2 Node  ──► /Torch (Int8) ──► callback
                                      ↓
                                  smbus2.write_byte(0x08, value)
                                      ↓
                                  Arduino Nano (I²C slave at 0x08)
                                      ↓
                                  Torch / LED hardware
```

## Hardware

| Component | Details |
|-----------|---------|
| SBC | Jetson Nano / Raspberry Pi |
| I²C Channel | Bus 1 (`/dev/i2c-1`) |
| Arduino I²C Address | `0x08` |
| Control Target | Torch, LED, or relay connected to Arduino |

## Package Structure

```
demo_torch/
├── demo_torch/
│   ├── __init__.py
│   └── torch.py     # Main node: subscribes /Torch → I²C → Arduino
├── resource/
├── package.xml
├── setup.cfg
└── setup.py
```

## File Explanation

### `torch.py` — `TorchControlNode`

**How it works:**

1. **Initializes I²C bus** at startup (`smbus2.SMBus(1)`)
   - If I²C unavailable (no hardware), falls back to **Mock mode** (logs without writing)
2. **Subscribes to `/Torch`** topic (`std_msgs/Int8`)
   - Stores the latest value in `self.torch_data`
3. **10Hz process loop** (`create_timer(0.1, self.process)`)
   - Every 100ms, sends `self.torch_data` to Arduino via `bus.write_byte(0x08, value)`
   - Logs success or error

**Command values (sent as Int8 by default):**

| Logical Command | Default I2C Byte | Custom Parameter mapping | Meaning |
|-------|---------|---|---|
| `0` | `0` | `torch_off_value` | Turn torch OFF |
| `1` | `1` | `torch_on_value` | Turn torch ON |
| `2` | `2` | N/A | Standby / no-op |

### ROS 2 Parameters

The node exposes the following parameters to customize behavior without modifying the code:
- **`led_state`**: Sets the initial torch state at startup, or dynamically updates it during runtime. (Default: `2` - standby, `0` - off, `1` - on)
- **`torch_on_value`**: The raw byte sent to the Arduino to turn the torch ON. (Default: `1`)
- **`torch_off_value`**: The raw byte sent to the Arduino to turn the torch OFF. (Default: `0`)

> [!IMPORTANT]
> **Resolving I²C Collision with Ultrasonic Sensors:**
> The ultrasonic sensor node (`ultrasonic_pub`) reads sensor values by requesting registers `0` and `1` from address `0x08`. Because `read_byte_data` performs a write of the register index first, the Arduino receives the bytes `0` and `1`. This causes the Arduino to interpret them as Torch ON/OFF commands, leaving the torch permanently ON because the right sensor (register `1`) is read last in the loop.
> 
> **To solve this without interference:**
> 1. Set the ROS parameters for the torch node to use custom, non-overlapping bytes (e.g., `10` for ON, `11` for OFF):
>    ```bash
>    ros2 run demo_torch torch_control --ros-args -p torch_on_value:=10 -p torch_off_value:=11
>    ```
> 2. Flash your Arduino Nano with the updated firmware shown below, which listens for `10` and `11` instead of `1` and `0`.

## How to Build

```bash
cd ~/arjuna2_ws
source /opt/ros/humble/setup.bash
colcon build --packages-select demo_torch --symlink-install
source install/setup.bash
```

## How to Run

### With Hardware (Jetson Nano + Arduino)

```bash
# Set I²C permissions
sudo chmod 666 /dev/i2c-1

# Start the torch control node with custom non-conflicting values (to prevent ultrasonic collision)
source ~/arjuna2_ws/install/setup.bash
ros2 run demo_torch torch_control --ros-args -p torch_on_value:=10 -p torch_off_value:=11

# In another terminal, turn the LED on or off dynamically using ROS 2 parameters:
ros2 param set /Torch_control led_state 1   # Turns LED ON (writes 10 to Arduino)
ros2 param set /Torch_control led_state 0   # Turns LED OFF (writes 11 to Arduino)

# Or publish to the topic:
ros2 topic pub /Torch std_msgs/msg/Int8 "{data: 1}" --once   # Turns ON
ros2 topic pub /Torch std_msgs/msg/Int8 "{data: 0}" --once   # Turns OFF
```

### Without Hardware (Mock Mode)

```bash
# Run normally — it will automatically fall back to mock mode
ros2 run demo_torch torch_control
```

Output:
```
[ERROR]: Failed to initialize I2C Bus: ... Running in Mock mode.
[DEBUG]: [MOCK] Data sent to Arduino: 2
```

## Arduino Firmware (Reference)

The Arduino sketch running on the slave should look like this to avoid collisions with the ultrasonic sensor registers:

```cpp
#include <Wire.h>

#define TORCH_PIN 13  // LED or relay pin

void setup() {
  Wire.begin(0x08);         // Set I2C address to 0x08
  Wire.onReceive(receiveData);
  pinMode(TORCH_PIN, OUTPUT);
}

void receiveData(int bytes) {
  while (Wire.available()) {
    byte cmd = Wire.read();
    // Using 10 and 11 resolves the conflict with ultrasonic register reads (0 and 1)
    if (cmd == 10) digitalWrite(TORCH_PIN, HIGH);
    else if (cmd == 11) digitalWrite(TORCH_PIN, LOW);
  }
}

void loop() { delay(10); }
```

## Key ROS 2 Concepts Demonstrated

| Concept | Where Used |
|---------|-----------|
| Subscribe to `std_msgs/Int8` | `callback` |
| Stateful data (retain last command) | `self.torch_data` |
| Hardware fallback / Mock mode | `__init__` I²C try/except |
| Periodic hardware write at 10Hz | `create_timer(0.1, self.process)` |
| I²C communication with smbus2 | `bus.write_byte(addr, data)` |

## Troubleshooting

| Problem | Solution |
|---------|---------|
| `Failed to initialize I2C Bus` | `sudo chmod 666 /dev/i2c-1` |
| Arduino not responding | Check wiring; verify address with `i2cdetect -y 1` |
| Wrong I²C channel | Change `SMBus(1)` to `SMBus(0)` for bus 0 |

## License
MIT — Newrro Tech
