# demo_pub_sub — Publisher / Subscriber Demo

The most fundamental ROS 2 communication pattern. A **Publisher** node sends string messages on a topic, and a **Subscriber** node receives and prints them.

## 🔑 Concept

> **Topic-based communication** is asynchronous and one-to-many. The publisher does not care who is listening; the subscriber does not care who is publishing. They are decoupled through a named topic.

```
Publisher ──► /pub_sub (std_msgs/String) ──► Subscriber
```

## Package Structure

```
demo_pub_sub/
├── demo_pub_sub/
│   ├── __init__.py
│   ├── Publisher.py      # Publishes "Hello World: N" every 0.5 s
│   └── Subscriber.py     # Prints every received string message
├── resource/
├── package.xml
├── setup.cfg
└── setup.py
```

## File Explanations

### `Publisher.py`
- Creates a ROS 2 node called `Publisher`
- Creates a publisher on the topic `/pub_sub` with message type `std_msgs/String`
- Uses a **0.5-second timer** to call `timer_callback` repeatedly
- Each callback publishes `"Hello World: N"` where N increments every call
- Logs each published message to the terminal

### `Subscriber.py`
- Creates a ROS 2 node called `Subscriber`
- Creates a subscription on topic `/pub_sub` with message type `std_msgs/String`
- `listener_callback` is called every time a message arrives
- Prints the received string to the ROS 2 log

## How to Build

```bash
cd ~/arjuna2_ws
source /opt/ros/humble/setup.bash
colcon build --packages-select demo_pub_sub --symlink-install
source install/setup.bash
```

## How to Run

Open **2 terminals**:

```bash
# Terminal 1 — Start the Publisher
source ~/arjuna2_ws/install/setup.bash
ros2 run demo_pub_sub Publisher

# Terminal 2 — Start the Subscriber
source ~/arjuna2_ws/install/setup.bash
ros2 run demo_pub_sub Subscriber
```

### Expected Output

**Terminal 1 (Publisher):**
```
[INFO] [publisher]: Publishing: "Hello World: 0"
[INFO] [publisher]: Publishing: "Hello World: 1"
[INFO] [publisher]: Publishing: "Hello World: 2"
```

**Terminal 2 (Subscriber):**
```
[INFO] [subscriber]: I heard: "Hello World: 0"
[INFO] [subscriber]: I heard: "Hello World: 1"
[INFO] [subscriber]: I heard: "Hello World: 2"
```

### Inspect the Topic (Optional)

```bash
# List topics
ros2 topic list

# Echo messages manually
ros2 topic echo /pub_sub

# View topic info
ros2 topic info /pub_sub
```

## Key ROS 2 Concepts Demonstrated

| Concept | Where Used |
|---------|-----------|
| `create_publisher(type, topic, qos)` | `Publisher.py` |
| `create_subscription(type, topic, callback, qos)` | `Subscriber.py` |
| `create_timer(period, callback)` | `Publisher.py` |
| `get_logger().info(msg)` | Both files |
| `std_msgs/msg/String` | Both files |

## License
MIT — Newrro Tech
