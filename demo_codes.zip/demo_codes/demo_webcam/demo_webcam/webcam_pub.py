import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
import cv2
from cv_bridge import CvBridge

class WebcamPublisher(Node):

    def __init__(self):
        super().__init__('webcam_publisher')
        
        # Declare parameters
        self.declare_parameter('device_index', 0)
        self.declare_parameter('frame_width', 640)
        self.declare_parameter('frame_height', 480)
        self.declare_parameter('fps', 30.0)

        # Get parameters
        self.device_index = self.get_parameter('device_index').get_parameter_value().integer_value
        self.frame_width = self.get_parameter('frame_width').get_parameter_value().integer_value
        self.frame_height = self.get_parameter('frame_height').get_parameter_value().integer_value
        self.fps = self.get_parameter('fps').get_parameter_value().double_value

        self.get_logger().info(
            f"Configuring Webcam: device_index={self.device_index}, "
            f"resolution={self.frame_width}x{self.frame_height}, fps={self.fps}"
        )

        # Publisher
        self.image_pub = self.create_publisher(Image, '/camera/image_raw', 10)
        self.bridge = CvBridge()
        
        self.cap = None
        self.cap_opened = False
        
        # Try initial open
        self.try_open_camera()

        # Timer based on FPS
        timer_period = 1.0 / self.fps
        self.timer = self.create_timer(timer_period, self.timer_callback)

    def try_open_camera(self):
        try:
            self.get_logger().info(f"Attempting to open camera index {self.device_index}...")
            self.cap = cv2.VideoCapture(self.device_index)
            if self.cap.isOpened():
                # Set resolution
                self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, self.frame_width)
                self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.frame_height)
                self.cap_opened = True
                self.get_logger().info("Camera successfully opened!")
            else:
                self.get_logger().warn(f"Failed to open camera index {self.device_index}. Will retry.")
                self.cap_opened = False
        except Exception as e:
            self.get_logger().error(f"Error opening camera: {e}")
            self.cap_opened = False

    def timer_callback(self):
        # If camera not open, try to reconnect
        if not self.cap_opened or self.cap is None or not self.cap.isOpened():
            self.try_open_camera()
            return

        try:
            ret, frame = self.cap.read()
            if not ret or frame is None:
                self.get_logger().warn("Failed to read frame from camera. Resetting connection.")
                self.cap.release()
                self.cap_opened = False
                return

            # Convert to ROS 2 Image message
            now = self.get_clock().now().to_msg()
            msg = self.bridge.cv2_to_imgmsg(frame, encoding="bgr8")
            msg.header.stamp = now
            msg.header.frame_id = "camera_optical_frame"
            
            # Publish
            self.image_pub.publish(msg)
        except Exception as e:
            self.get_logger().error(f"Error in timer callback: {e}")

    def __del__(self):
        if self.cap is not None:
            self.cap.release()

def main(args=None):
    rclpy.init(args=args)
    node = WebcamPublisher()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        if rclpy.ok():
            node.destroy_node()
            rclpy.shutdown()

if __name__ == '__main__':
    main()
