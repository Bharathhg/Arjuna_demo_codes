import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
import cv2
from cv_bridge import CvBridge
import os

class WebcamSubscriber(Node):

    def __init__(self):
        super().__init__('webcam_subscriber')
        self.subscription = self.create_subscription(
            Image,
            '/camera/image_raw',
            self.listener_callback,
            10
        )
        self.bridge = CvBridge()
        self.has_display = os.environ.get('DISPLAY') is not None
        if self.has_display:
            self.get_logger().info("Display environment detected. Live view will be shown.")
        else:
            self.get_logger().info("No display environment detected (headless). Logging frame receipts only.")

    def listener_callback(self, msg):
        try:
            # Convert ROS Image message to OpenCV image
            cv_image = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
            h, w, _ = cv_image.shape

            if self.has_display:
                cv2.imshow("Webcam Live Feed", cv_image)
                # cv2.waitKey(1) is required to refresh OpenCV window
                cv2.waitKey(1)
            else:
                self.get_logger().info(f"Received frame: {w}x{h}", throttle_duration_sec=2.0)
        except Exception as e:
            self.get_logger().error(f"Error processing frame: {e}")

    def __del__(self):
        if self.has_display:
            cv2.destroyAllWindows()

def main(args=None):
    rclpy.init(args=args)
    node = WebcamSubscriber()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        if rclpy.ok():
            node.destroy_node()
            rclpy.shutdown()

if __name__ == '__main__':
    main()
