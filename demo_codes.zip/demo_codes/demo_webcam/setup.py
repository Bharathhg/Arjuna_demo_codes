from setuptools import find_packages, setup

package_name = 'demo_webcam'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/launch', ['launch/webcam.launch.py']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='hacker',
    maintainer_email='hacker@todo.todo',
    description='Demo package for standard USB webcam',
    license='Apache-2.0',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
        'console_scripts': [
            'webcam_pub = demo_webcam.webcam_pub:main',
            'webcam_sub = demo_webcam.webcam_sub:main'
        ],
    },
)
