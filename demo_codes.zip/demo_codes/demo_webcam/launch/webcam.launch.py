import os
from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration

def generate_launch_description():
    # Declare arguments
    device_index_arg = DeclareLaunchArgument(
        'device_index',
        default_value='0',
        description='USB device index of the webcam'
    )
    
    frame_width_arg = DeclareLaunchArgument(
        'frame_width',
        default_value='640',
        description='Frame width of the camera feed'
    )
    
    frame_height_arg = DeclareLaunchArgument(
        'frame_height',
        default_value='480',
        description='Frame height of the camera feed'
    )
    
    fps_arg = DeclareLaunchArgument(
        'fps',
        default_value='30.0',
        description='FPS of the camera feed'
    )

    # Node configuration
    webcam_pub_node = Node(
        package='demo_webcam',
        executable='webcam_pub',
        name='webcam_publisher',
        output='screen',
        parameters=[{
            'device_index': LaunchConfiguration('device_index'),
            'frame_width': LaunchConfiguration('frame_width'),
            'frame_height': LaunchConfiguration('frame_height'),
            'fps': LaunchConfiguration('fps')
        }]
    )

    webcam_sub_node = Node(
        package='demo_webcam',
        executable='webcam_sub',
        name='webcam_subscriber',
        output='screen'
    )

    return LaunchDescription([
        device_index_arg,
        frame_width_arg,
        frame_height_arg,
        fps_arg,
        webcam_pub_node,
        webcam_sub_node
    ])
