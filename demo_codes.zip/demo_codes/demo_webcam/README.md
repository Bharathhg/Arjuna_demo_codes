# demo_webcam — USB Webcam Publisher / Subscriber Demo

Demonstrates how to capture frames from a **standard USB webcam** using **OpenCV** and publish them as ROS 2 `sensor_msgs/Image` messages — the standard format used by all ROS 2 vision pipelines.

## 🔑 Concept

> Cameras are one of the most important sensors on a robot. This demo shows how to bridge a physical USB camera into the ROS 2 ecosystem using `cv_bridge`, making the image stream available to any ROS 2 node (navigation, QR detection, object recognition, etc.).

```
USB Webcam → cv2.VideoCapture → CvBridge → sensor_msgs/Image → /camera/image_raw
```

## Hardware

| Component | Details |
|-----------|---------|
| Camera | Any standard USB webcam (UVC compatible) |
| Device Index | `0` (default, `/dev/video0`) |
| Default Resolution | `640 × 480` |
| Default FPS | `30` |

## Package Structure

```
demo_webcam/
├── demo_webcam/
│   ├── __init__.py
│   ├── webcam_pub.py    # Captures frames → publishes /camera/image_raw
│   └── webcam_sub.py    # Subscribes → displays in OpenCV window
├── launch/
│   └── (launch files)
├── resource/
├── package.xml
├── setup.cfg
└── setup.py
```

## File Explanations

### `webcam_pub.py` — `WebcamPublisher`

**Configurable ROS 2 Parameters:**

| Parameter | Default | Description |
|-----------|---------|-------------|
| `device_index` | `0` | Camera device index (`/dev/video0`) |
| `frame_width` | `640` | Frame width in pixels |
| `frame_height` | `480` | Frame height in pixels |
| `fps` | `30.0` | Target frame rate |

**How it works:**

1. Reads parameters and logs configuration
2. Opens the camera with `cv2.VideoCapture(device_index)`
3. Sets resolution via `cap.set(CAP_PROP_FRAME_WIDTH, ...)` and `CAP_PROP_FRAME_HEIGHT`
4. Creates a timer at `1/fps` seconds
5. Each timer tick:
   - Reads a frame: `ret, frame = cap.read()`
   - If read fails, releases and tries to reconnect (auto-recovery)
   - Converts OpenCV BGR frame to ROS 2 Image: `bridge.cv2_to_imgmsg(frame, "bgr8")`
   - Stamps and publishes to `/camera/image_raw`

**Auto-Recovery:** If the camera disconnects or returns a bad frame, the node automatically tries to reopen it instead of crashing.

### `webcam_sub.py`

- Subscribes to `/camera/image_raw`
- Converts ROS 2 Image back to OpenCV using `bridge.imgmsg_to_cv2(msg, "bgr8")`
- Displays frames in a live OpenCV window using `cv2.imshow`

## How to Build

```bash
cd ~/arjuna2_ws
source /opt/ros/humble/setup.bash
colcon build --packages-select demo_webcam --symlink-install
source install/setup.bash
```

## How to Run

```bash
# Terminal 1 — Camera Publisher
source ~/arjuna2_ws/install/setup.bash
ros2 run demo_webcam webcam_pub

# Terminal 2 — View the Camera Feed
source ~/arjuna2_ws/install/setup.bash
ros2 run demo_webcam webcam_sub
```

### Custom Parameters

```bash
# Use second camera (/dev/video1), 1080p, 15fps
ros2 run demo_webcam webcam_pub --ros-args \
  -p device_index:=1 \
  -p frame_width:=1920 \
  -p frame_height:=1080 \
  -p fps:=15.0
```

### View with rqt_image_view

```bash
# Install
sudo apt install ros-humble-rqt-image-view

# Launch viewer
ros2 run rqt_image_view rqt_image_view /camera/image_raw
```

### Record & Playback Camera Feed

```bash
# Record
ros2 bag record /camera/image_raw -o my_camera_bag

# Playback
ros2 bag play my_camera_bag
```

## Topic Information

| Topic | Type | Description |
|-------|------|-------------|
| `/camera/image_raw` | `sensor_msgs/Image` | Raw BGR8 frames from webcam |

**Message fields:**

| Field | Description |
|-------|-------------|
| `header.stamp` | ROS 2 timestamp |
| `header.frame_id` | `"camera_optical_frame"` |
| `encoding` | `"bgr8"` |
| `height`, `width` | Frame dimensions |
| `data` | Raw pixel bytes |

## Troubleshooting

| Problem | Solution |
|---------|---------|
| `Failed to open camera index 0` | Try index 1, 2; check `ls /dev/video*` |
| Permission denied | `sudo chmod 666 /dev/video0` or `sudo usermod -aG video $USER` |
| Black frames | Camera needs a moment to warm up; add `time.sleep(1)` |
| Low FPS | Reduce resolution or lower `fps` parameter |

## Key ROS 2 Concepts Demonstrated

| Concept | Where Used |
|---------|-----------|
| `sensor_msgs/Image` message | `webcam_pub.py` |
| `CvBridge.cv2_to_imgmsg` | `webcam_pub.py` |
| `CvBridge.imgmsg_to_cv2` | `webcam_sub.py` |
| ROS 2 parameters | `device_index`, `frame_width`, `frame_height`, `fps` |
| Auto-recovery on hardware failure | `try_open_camera()` |

## License
MIT — Newrro Tech
