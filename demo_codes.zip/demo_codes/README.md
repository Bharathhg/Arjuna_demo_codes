# demo_codes — ROS 2 Demo & Example Programs

A collection of standalone ROS 2 example packages for learning, testing, and prototyping robot components.

## Sub-packages

| Folder | Description |
|--------|-------------|
| `demo_action/` | ROS 2 Action server and client example |
| `demo_class_object/` | OOP-style ROS 2 node demo |
| `demo_custom_msg/` | Custom message type definition and usage |
| `demo_imu/` | Subscribe to IMU data and print orientation |
| `demo_lidar/` | Subscribe to `/scan` and print LIDAR ranges |
| `demo_okd_lite_camera/` | OKdo Lite camera interface demo |
| `demo_pub_sub/` | Basic publisher / subscriber demo |
| `demo_service/` | ROS 2 service server and client demo |
| `demo_ticks/` | Read encoder tick values |
| `demo_torch/` | PyTorch model inference in a ROS 2 node |
| `demo_ultrasonic/` | Ultrasonic distance sensor demo |
| `demo_webcam/` | USB webcam capture and publish |

## How to Build

```bash
cd ~/arjuna2_ws
source /opt/ros/humble/setup.bash
colcon build --packages-select demo_pub_sub demo_service demo_webcam --symlink-install
source install/setup.bash
```

## How to Run (examples)

```bash
source ~/arjuna2_ws/install/setup.bash

# Publisher / Subscriber
ros2 run demo_pub_sub talker
ros2 run demo_pub_sub listener

# Service demo
ros2 run demo_service server
ros2 run demo_service client

# Webcam demo
ros2 run demo_webcam webcam_pub

# LIDAR demo
ros2 run demo_lidar lidar_reader

# IMU demo
ros2 run demo_imu imu_reader
```

## License
MIT — Newrro Tech
