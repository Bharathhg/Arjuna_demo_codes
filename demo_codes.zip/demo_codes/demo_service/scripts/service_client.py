#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from demo_service.srv import CustomSrv
import sys

class ServiceClientNode(Node):
    def __init__(self):
        super().__init__('service_client_node')
        self.client = self.create_client(CustomSrv, 'add_two_ints')
        
        while not self.client.wait_for_service(timeout_sec=1.0):
            self.get_logger().info("Service 'add_two_ints' not available, waiting...")
            
        self.req = CustomSrv.Request()

    def send_request(self, a, b):
        self.req.a = a
        self.req.b = b
        self.future = self.client.call_async(self.req)
        rclpy.spin_until_future_complete(self, self.future)
        return self.future.result()

def main(args=None):
    rclpy.init(args=args)
    node = ServiceClientNode()
    
    a = int(sys.argv[1]) if len(sys.argv) > 1 else 3
    b = int(sys.argv[2]) if len(sys.argv) > 2 else 5
    
    node.get_logger().info(f"Sending request: a={a}, b={b}...")
    response = node.send_request(a, b)
    if response is not None:
        node.get_logger().info(f"Result of service call: {a} + {b} = {response.sum}")
    else:
        node.get_logger().error("Service call failed.")
        
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
