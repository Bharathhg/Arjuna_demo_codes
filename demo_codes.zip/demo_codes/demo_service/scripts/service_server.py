#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from demo_service.srv import CustomSrv

class ServiceServerNode(Node):
    def __init__(self):
        super().__init__('service_server_node')
        self.srv = self.create_service(CustomSrv, 'add_two_ints', self.add_two_ints_callback)
        self.get_logger().info("Service Server is ready to receive requests.")

    def add_two_ints_callback(self, request, response):
        response.sum = request.a + request.b
        self.get_logger().info(f"Incoming request: a={request.a}, b={request.b} | Sending response: sum={response.sum}")
        return response

def main(args=None):
    rclpy.init(args=args)
    node = ServiceServerNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
