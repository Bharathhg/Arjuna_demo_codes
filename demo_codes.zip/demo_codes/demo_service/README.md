# demo_service — Service Server / Client Demo

Demonstrates ROS 2 **Services** — synchronous request/response communication. One node sends a request and waits for a reply.

## 🔑 Concept

> **Services** are synchronous and one-to-one. The client sends a request and **blocks** until the server responds. Unlike topics, services are used for actions that need a guaranteed response (e.g., "move to position and tell me when done").

```
Client ──► [Request: a=3, b=5] ──► Server
       ◄── [Response: sum=8]   ◄──
```

## Package Structure

```
demo_service/
├── scripts/
│   ├── service_server.py   # Server: adds two integers
│   └── service_client.py   # Client: sends a + b and prints the result
├── srv/
│   └── CustomSrv.srv       # Custom service definition: int64 a, b → int64 sum
├── include/
├── src/
├── CMakeLists.txt
└── package.xml
```

## File Explanations

### `srv/CustomSrv.srv`
Defines the custom service interface:
```
int64 a
int64 b
---
int64 sum
```
- **Above `---`** = Request fields (sent by client)
- **Below `---`** = Response fields (sent back by server)

### `service_server.py`
- Creates a ROS 2 node called `service_server_node`
- Registers a service named `add_two_ints` using type `CustomSrv`
- `add_two_ints_callback` receives `a` and `b`, computes `sum = a + b`, and returns it
- Logs each request and response

### `service_client.py`
- Creates a ROS 2 node called `service_client_node`
- Waits for the `add_two_ints` service to become available
- Sends a request with two integers
- Prints the `sum` result received from the server

## How to Build

```bash
cd ~/arjuna2_ws
source /opt/ros/humble/setup.bash
colcon build --packages-select demo_service --symlink-install
source install/setup.bash
```

## How to Run

Open **2 terminals**:

```bash
# Terminal 1 — Start the Server (keep running)
source ~/arjuna2_ws/install/setup.bash
ros2 run demo_service service_server

# Terminal 2 — Send a Request from Client
source ~/arjuna2_ws/install/setup.bash
ros2 run demo_service service_client
```

### Call the Service Manually (Optional)

```bash
# Call directly from terminal without using client node
ros2 service call /add_two_ints demo_service/srv/CustomSrv "{a: 10, b: 25}"
```

Expected response:
```
response:
  demo_service.srv.CustomSrv_Response(sum=35)
```

## Key ROS 2 Concepts Demonstrated

| Concept | Where Used |
|---------|-----------|
| `create_service(type, name, callback)` | `service_server.py` |
| `create_client(type, name)` | `service_client.py` |
| `client.wait_for_service()` | `service_client.py` |
| `client.call_async(request)` | `service_client.py` |
| Custom `.srv` interface | `srv/CustomSrv.srv` |

## License
MIT — Newrro Tech
