# demo_okd_lite_camera — OKdo Lite (OAK-D) Depth Camera Demo

Demonstrates how to use the **OKdo Lite / Luxonis OAK-D** depth camera with **DepthAI** to publish both **RGB color frames** and **stereo depth maps** into ROS 2.

## 🔑 Concept

> The OAK-D camera has **three lenses**: one RGB sensor and two monochrome stereo cameras. An onboard VPU processes the stereo pair to compute a **depth map** (how far each pixel is from the camera) in real time without using CPU resources. This demo publishes both the color image and the depth image as standard ROS 2 messages.

```
OAK-D Camera (USB)
  ├── RGB Camera     → DepthAI Pipeline → /camera/image_raw       (bgr8)
  └── Stereo Pair    → StereoDepth Node → /camera/depth/image_raw (16UC1, mm)
```

## Hardware

| Component | Details |
|-----------|---------|
| Camera | OKdo Lite / Luxonis OAK-D |
| Interface | USB 3.0 (SuperSpeed required) |
| RGB Resolution | `640 × 480` preview (up to 1080p) |
| Mono Cameras | `400P` resolution each |
| FPS | 30 FPS |
| Library | DepthAI SDK (`depthai`) |

## Package Structure

```
demo_okd_lite_camera/
├── demo_okd_lite_camera/
│   ├── __init__.py
│   ├── okd_camera_pub.py    # OAK-D pipeline: RGB + Depth → ROS 2 topics
│   └── okd_camera_sub.py    # Subscribes to RGB and Depth topics, displays them
├── scripts/
│   └── (utility scripts)
├── launch/
│   └── (launch files)
├── resource/
├── package.xml
├── setup.cfg
└── setup.py
```

## File Explanations

### `okd_camera_pub.py` — `CameraPublisher`

**DepthAI Pipeline Setup:**

```
ColorCamera (RGB, 1080P, 30fps)
    └── preview (640×480) → XLinkOut("rgb")

MonoCamera LEFT (400P)  ─┐
                          ├→ StereoDepth (HIGH_DENSITY, subpixel) → XLinkOut("depth")
MonoCamera RIGHT (400P) ─┘
```

**Processing loop (30Hz timer):**

1. `q_rgb.tryGet()` — non-blocking poll for a new RGB frame
   - If available: converts with `getCvFrame()` → `cv2_to_imgmsg(frame, "bgr8")` → publishes `/camera/image_raw`
2. `q_depth.tryGet()` — non-blocking poll for a new depth frame
   - If available: gets raw array with `getFrame()` → `cv2_to_imgmsg(depth_frame, "16UC1")` → publishes `/camera/depth/image_raw`
   - `16UC1` = unsigned 16-bit int, 1 channel. Pixel value = distance in **millimeters**

**Published topics:**

| Topic | Type | Encoding | Description |
|-------|------|----------|-------------|
| `/camera/image_raw` | `sensor_msgs/Image` | `bgr8` | Color RGB preview |
| `/camera/depth/image_raw` | `sensor_msgs/Image` | `16UC1` | Depth map (mm) |

### `okd_camera_sub.py`

- Subscribes to both `/camera/image_raw` and `/camera/depth/image_raw`
- Displays both streams in OpenCV windows
- For depth display, normalizes the 16-bit depth to 8-bit for visibility

## How to Install DepthAI

```bash
pip3 install depthai
```

Or for Jetson Nano (ARM):
```bash
python3 -m pip install depthai
```

## How to Build

```bash
cd ~/arjuna2_ws
source /opt/ros/humble/setup.bash
colcon build --packages-select demo_okd_lite_camera --symlink-install
source install/setup.bash
```

## How to Run

```bash
# Terminal 1 — Camera Publisher (requires OAK-D connected via USB 3.0)
source ~/arjuna2_ws/install/setup.bash
ros2 run demo_okd_lite_camera okd_camera_pub

# Terminal 2 — View Both Streams
source ~/arjuna2_ws/install/setup.bash
ros2 run demo_okd_lite_camera okd_camera_sub
```

### View with rqt_image_view

```bash
# View RGB
ros2 run rqt_image_view rqt_image_view /camera/image_raw

# View Depth (as colormap)
ros2 run rqt_image_view rqt_image_view /camera/depth/image_raw
```

### Inspect Published Topics

```bash
ros2 topic list
ros2 topic info /camera/image_raw
ros2 topic hz /camera/image_raw        # Should be ~30 Hz
ros2 topic hz /camera/depth/image_raw  # Should be ~30 Hz
```

## Depth Image Encoding

The depth image uses `16UC1` encoding:
- Each pixel = **distance in millimeters** (uint16)
- `0` = no valid depth measurement
- `1000` = 1.0 metre
- `5000` = 5.0 metres

To convert pixel value to meters in Python:
```python
depth_m = depth_frame[row, col] / 1000.0
```

## StereoDepth Mode Explained

| Setting | Value | Effect |
|---------|-------|--------|
| `PresetMode` | `HIGH_DENSITY` | Maximizes coverage of depth map |
| `setSubpixel(True)` | Enabled | Sub-pixel interpolation → smoother edges |

Alternative preset: `HIGH_ACCURACY` — fewer points but more precise.

## Key ROS 2 Concepts Demonstrated

| Concept | Where Used |
|---------|-----------|
| Multiple publishers from one node | RGB + Depth topics |
| `16UC1` image encoding | Depth map |
| Non-blocking queue polling | `q_rgb.tryGet()` |
| DepthAI pipeline graph | `okd_camera_pub.py` |
| CvBridge BGR8 and 16UC1 | `cv2_to_imgmsg` |

## Troubleshooting

| Problem | Solution |
|---------|---------|
| `Failed to start OAK-D` | Use USB 3.0 port; try `depthai_demo` to verify |
| Low depth quality | Clean lenses; improve lighting |
| Import error `depthai` | `pip3 install depthai` |
| USB permission | `sudo usermod -aG video $USER` then log out/in |

## License
MIT — Newrro Tech
