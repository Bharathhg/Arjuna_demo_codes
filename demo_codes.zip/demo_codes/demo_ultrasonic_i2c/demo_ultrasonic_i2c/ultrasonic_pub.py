import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Range
import smbus2
from collections import deque
import statistics

class UltrasonicPublisher(Node):

    def __init__(self):
        super().__init__('demo_ultrasonic_publisher')
        
        # Publishers for two sensors
        self.pub_left = self.create_publisher(Range, '/ultrasonic/left', 10)
        self.pub_right = self.create_publisher(Range, '/ultrasonic/right', 10)
        
        # Filtering windows
        self.window_size = 5
        self.left_history = deque(maxlen=self.window_size)
        self.right_history = deque(maxlen=self.window_size)

        # I2C configuration
        self.bus_num = 1
        self.addr = 0x08
        
        try:
            self.bus = smbus2.SMBus(self.bus_num)
            self.get_logger().info(f"Ultrasonic SMBus initialized on bus {self.bus_num} at address {hex(self.addr)}")
            # 10Hz reading frequency
            self.timer = self.create_timer(0.1, self.read_sensors)
        except Exception as e:
            self.get_logger().error(f"Failed to open I2C bus {self.bus_num}: {e}")
            self.bus = None

    def read_sensors(self):
        if self.bus is None:
            return

        try:
            # Read Right sensor first (writes 1), then Left sensor (writes 0)
            # This ensures the final I2C command received by Arduino is 0 (OFF),
            # preventing the Torch from staying ON and crashing the controller.
            d2_cm = self.bus.read_byte_data(self.addr, 1)
            d1_cm = self.bus.read_byte_data(self.addr, 0)
            
            # Convert cm to m and store in history
            # Skip 0 or 255 as they often indicate errors or out of range
            if 0 < d1_cm < 255:
                self.left_history.append(float(d1_cm) / 100.0)
            if 0 < d2_cm < 255:
                self.right_history.append(float(d2_cm) / 100.0)

            # Publish median values
            if self.left_history:
                self.pub_left.publish(self.create_range_msg('ultrasonic_left', statistics.median(self.left_history)))
            if self.right_history:
                self.pub_right.publish(self.create_range_msg('ultrasonic_right', statistics.median(self.right_history)))

        except Exception as e:
            self.get_logger().warn(f"Ultrasonic read error: {e}")

    def create_range_msg(self, frame_id, distance_m):
        msg = Range()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = frame_id
        msg.radiation_type = Range.ULTRASOUND
        msg.field_of_view = 0.523 # 30 degrees
        msg.min_range = 0.02
        msg.max_range = 2.0 # Standard for these sensors via I2C
        msg.range = float(distance_m)
        return msg

def main(args=None):
    rclpy.init(args=args)
    node = UltrasonicPublisher()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        if rclpy.ok():
            if node.bus:
                node.bus.close()
            node.destroy_node()
            rclpy.shutdown()

if __name__ == '__main__':
    main()

if __name__ == '__main__':
    main()
