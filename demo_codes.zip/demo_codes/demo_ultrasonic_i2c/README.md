# demo_ultrasonic — Ultrasonic Sensor Publisher / Subscriber Demo

Demonstrates how to read **dual ultrasonic distance sensors** via **I²C** (through an Arduino bridge) and publish filtered measurements as standard ROS 2 `sensor_msgs/Range` messages.

## 🔑 Concept

> Ultrasonic sensors (HC-SR04) measure distance using sound reflection. Since they are analog/digital sensors, they are read by an **Arduino Nano** which packages the readings and sends them over **I²C** to the SBC. This demo reads both left and right sensor values, applies a **median filter** to reduce noise, and publishes them to ROS 2.

```
HC-SR04 (Left)  → Arduino Nano (I²C slave 0x08) → SMBus → ROS 2 Node → /ultrasonic/left
HC-SR04 (Right) →                                         → ROS 2 Node → /ultrasonic/right
```

## Hardware

| Component | Details |
|-----------|---------|
| Sensors | 2× HC-SR04 ultrasonic distance sensors |
| Bridge | Arduino Nano (reads sensors, serves over I²C) |
| I²C Bus | Bus 1 (`/dev/i2c-1`) |
| Arduino Address | `0x08` |
| Sensor Indices | Left = register `0`, Right = register `1` |
| Range | 2 cm – 200 cm |

## Package Structure

```
demo_ultrasonic/
├── demo_ultrasonic/
│   ├── __init__.py
│   ├── ultrasonic_pub.py   # Reads 2 sensors via I²C → /ultrasonic/left & /ultrasonic/right
│   └── ultrasonic_sub.py   # Subscribes to /ultrasonic/* and prints distances
├── scripts/
│   └── (utility scripts)
├── launch/
│   └── (launch files)
├── resource/
├── package.xml
├── setup.cfg
└── setup.py
```

## File Explanations

### `ultrasonic_pub.py` — `UltrasonicPublisher`

**Reading pipeline:**

#### 1. I²C Read (10Hz)
```python
d1_cm = bus.read_byte_data(0x08, 0)  # Left sensor (cm)
d2_cm = bus.read_byte_data(0x08, 1)  # Right sensor (cm)
```

#### 2. Noise Filtering
Values of `0` (no echo) and `255` (I²C error/out-of-range) are discarded:
```python
if 0 < d1_cm < 255:
    self.left_history.append(float(d1_cm) / 100.0)  # cm → meters
```

A sliding window of the last **5 readings** is kept (`collections.deque(maxlen=5)`), and the **median** is published instead of raw values — this removes outlier spikes.

#### 3. `sensor_msgs/Range` Message

| Field | Value |
|-------|-------|
| `radiation_type` | `ULTRASOUND` |
| `field_of_view` | `0.523 rad` (≈ 30°) |
| `min_range` | `0.02 m` |
| `max_range` | `2.00 m` |
| `range` | Median filtered distance (m) |

**Published topics:**
- `/ultrasonic/left` — left sensor distance
- `/ultrasonic/right` — right sensor distance

### `ultrasonic_sub.py`

- Subscribes to both `/ultrasonic/left` and `/ultrasonic/right`
- Prints distance readings in real time

## How to Build

```bash
cd ~/arjuna2_ws
source /opt/ros/humble/setup.bash
colcon build --packages-select demo_ultrasonic --symlink-install
source install/setup.bash
```

## How to Run

### Prerequisites

```bash
pip3 install smbus2
sudo chmod 666 /dev/i2c-1
i2cdetect -y 1   # Verify Arduino shows at 0x08
```

```bash
# Terminal 1 — Publisher (requires I²C hardware)
source ~/arjuna2_ws/install/setup.bash
ros2 run demo_ultrasonic ultrasonic_pub

# Terminal 2 — Subscriber
source ~/arjuna2_ws/install/setup.bash
ros2 run demo_ultrasonic ultrasonic_sub
```

### View Range Data Manually

```bash
ros2 topic echo /ultrasonic/left
ros2 topic echo /ultrasonic/right
ros2 topic hz /ultrasonic/left   # Should be ~10 Hz
```

### Expected Output (Subscriber)
```
[INFO]: Left: 0.35 m | Right: 0.82 m
[INFO]: Left: 0.34 m | Right: 0.81 m
[INFO]: Left: 0.34 m | Right: 0.83 m
```

## Why Median Filter?

| Reading 1 | Reading 2 | Reading 3 | Reading 4 | Reading 5 | Median |
|-----------|-----------|-----------|-----------|-----------|--------|
| 0.35 | 0.34 | **2.00** | 0.35 | 0.34 | **0.35** |

Without filtering, a single erratic reading of 2.0 m would cause the robot to think an obstacle disappeared. Median filtering keeps the output stable.

## Key ROS 2 Concepts Demonstrated

| Concept | Where Used |
|---------|-----------|
| Multiple publishers from one node | `pub_left`, `pub_right` |
| `sensor_msgs/Range` message | `create_range_msg()` |
| Sliding window deque filter | `left_history`, `right_history` |
| I²C byte read via smbus2 | `read_byte_data()` |
| Graceful cleanup (`bus.close()`) | `finally` block |

## Troubleshooting

| Problem | Solution |
|---------|---------|
| `Failed to open I2C bus` | Run `sudo chmod 666 /dev/i2c-1` |
| All readings are `10.0 m` | Arduino not responding; check wiring |
| `255` readings | Sensor out of range or I²C error |
| Torch turns ON when running ultrasonic | Register/command conflict. Ultrasonic reads from register `1` (Right sensor), which Arduino interprets as Torch ON. Solution: update Arduino code to use commands `10` (ON) and `11` (OFF) for Torch, and pass these to `demo_torch` as parameters. See `demo_torch` README. |

## License
MIT — Newrro Tech
