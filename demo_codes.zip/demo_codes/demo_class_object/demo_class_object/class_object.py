#!/usr/bin/env python3

import rclpy
from rclpy.node import Node

class OOPExampleNode(Node):
    """
    A simple node demonstrating object-oriented programming (OOP) principles in ROS 2.
    It inherits from rclpy.node.Node, declares a parameter, uses a timer, and handles logging.
    """
    def __init__(self):
        super().__init__('oop_example_node')
        
        # 1. Parameter Declaration
        self.declare_parameter('timer_period', 1.0) # default value: 1.0s
        timer_period = self.get_parameter('timer_period').get_parameter_value().double_value
        
        # 2. State variable
        self.counter = 0
        
        # 3. Create a timer callback
        self.timer = self.create_timer(timer_period, self.timer_callback)
        self.get_logger().info("OOP Example Node has been initialized.")

    def timer_callback(self):
        self.counter += 1
        self.get_logger().info(f"Timer fired! Counter value: {self.counter}")

def main(args=None):
    # Initialize the ROS 2 Python client library
    rclpy.init(args=args)
    
    # Instantiate the OOP node object
    node = OOPExampleNode()
    
    try:
        # Spin the node so callbacks can execute
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info("Node interrupted by user.")
    finally:
        # Clean up and shutdown
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
