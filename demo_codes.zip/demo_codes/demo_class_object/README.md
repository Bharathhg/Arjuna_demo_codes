# demo_class_object — OOP Node Demo

Demonstrates how to build a properly structured **Object-Oriented** ROS 2 node using Python class inheritance, parameters, timers, and logging.

## 🔑 Concept

> All real ROS 2 nodes are written as classes that inherit from `rclpy.node.Node`. This demo teaches the correct structure: how to declare parameters, create timers, and use the node's built-in logger.

## Package Structure

```
demo_class_object/
├── demo_class_object/
│   ├── __init__.py
│   └── class_object.py   # OOP node with parameter, timer, and counter
├── resource/
├── package.xml
├── setup.cfg
└── setup.py
```

## File Explanation

### `class_object.py`

The node class `OOPExampleNode` inherits from `rclpy.node.Node` and demonstrates 3 core OOP patterns:

#### 1. ROS 2 Parameter Declaration
```python
self.declare_parameter('timer_period', 1.0)
timer_period = self.get_parameter('timer_period').get_parameter_value().double_value
```
- Declares a parameter named `timer_period` with a default of `1.0` seconds
- Parameters can be changed at runtime via CLI without modifying source code

#### 2. State Variable (Instance Variable)
```python
self.counter = 0
```
- Instance variables persist across timer callbacks
- This is fundamental to stateful robot behavior

#### 3. Timer Callback
```python
self.timer = self.create_timer(timer_period, self.timer_callback)

def timer_callback(self):
    self.counter += 1
    self.get_logger().info(f"Timer fired! Counter value: {self.counter}")
```
- Timer fires repeatedly every `timer_period` seconds
- Each fire calls `timer_callback` which increments and logs the counter

## How to Build

```bash
cd ~/arjuna2_ws
source /opt/ros/humble/setup.bash
colcon build --packages-select demo_class_object --symlink-install
source install/setup.bash
```

## How to Run

```bash
# Run with default timer period (1.0 second)
source ~/arjuna2_ws/install/setup.bash
ros2 run demo_class_object class_object

# Run with a custom timer period (0.5 seconds = 2Hz)
ros2 run demo_class_object class_object --ros-args -p timer_period:=0.5
```

### Expected Output
```
[INFO] [oop_example_node]: OOP Example Node has been initialized.
[INFO] [oop_example_node]: Timer fired! Counter value: 1
[INFO] [oop_example_node]: Timer fired! Counter value: 2
[INFO] [oop_example_node]: Timer fired! Counter value: 3
```

### Override Parameter at Runtime

```bash
# Change timer period to 2 seconds via CLI
ros2 run demo_class_object class_object --ros-args -p timer_period:=2.0

# Check running parameters
ros2 param list /oop_example_node
ros2 param get /oop_example_node timer_period
```

## Key ROS 2 Concepts Demonstrated

| Concept | Code Location |
|---------|--------------|
| Class inheritance from `Node` | `class OOPExampleNode(Node)` |
| `declare_parameter(name, default)` | `__init__` method |
| `get_parameter(name).get_parameter_value()` | `__init__` method |
| `create_timer(period, callback)` | `__init__` method |
| `get_logger().info(msg)` | `timer_callback` |
| `KeyboardInterrupt` graceful shutdown | `main()` |

## Why This Pattern Matters

Every node in this workspace — `ArjunaController`, `BNO055Publisher`, `LidarSubscriber` — follows this exact pattern. Mastering this demo means you understand the skeleton of every ROS 2 node.

## License
MIT — Newrro Tech
