#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from demo_custom_msg.msg import CustomMsg

class CustomMsgPublisher(Node):
    def __init__(self):
        super().__init__('custom_msg_publisher')
        self.publisher = self.create_publisher(CustomMsg, 'custom_topic', 10)
        self.timer = self.create_timer(1.0, self.timer_callback)
        self.counter = 0
        self.get_logger().info("Custom Message Publisher node started.")

    def timer_callback(self):
        msg = CustomMsg()
        msg.description = "Hello from Custom Message Publisher!"
        msg.value = self.counter
        
        self.publisher.publish(msg)
        self.get_logger().info(f"Published custom message: description='{msg.description}', value={msg.value}")
        self.counter += 1

def main(args=None):
    rclpy.init(args=args)
    node = CustomMsgPublisher()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
