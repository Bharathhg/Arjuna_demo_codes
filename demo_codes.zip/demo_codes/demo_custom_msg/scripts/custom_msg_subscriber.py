#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from demo_custom_msg.msg import CustomMsg

class CustomMsgSubscriber(Node):
    def __init__(self):
        super().__init__('custom_msg_subscriber')
        self.subscription = self.create_subscription(
            CustomMsg,
            'custom_topic',
            self.listener_callback,
            10
        )
        self.get_logger().info("Custom Message Subscriber node started.")

    def listener_callback(self, msg):
        self.get_logger().info(f"Received custom message: description='{msg.description}', value={msg.value}")

def main(args=None):
    rclpy.init(args=args)
    node = CustomMsgSubscriber()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
