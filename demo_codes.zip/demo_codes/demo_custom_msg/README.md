# demo_custom_msg — Custom Message Demo

Demonstrates how to define and use your own **custom ROS 2 message type** — going beyond the standard `std_msgs`, `geometry_msgs`, etc.

## 🔑 Concept

> Standard message types cover most use cases, but sometimes you need a message with specific fields for your robot. This demo shows how to create a `.msg` file, build it into a ROS 2 package, and use it in publisher/subscriber nodes.

```
CustomMsgPublisher ──► /custom_topic (CustomMsg) ──► CustomMsgSubscriber
```

## Package Structure

```
demo_custom_msg/
├── msg/
│   └── CustomMsg.msg           # Custom message definition: string + int32
├── scripts/
│   ├── custom_msg_publisher.py # Publishes the custom message every 1 second
│   └── custom_msg_subscriber.py# Subscribes and prints each received message
├── include/
├── src/
├── CMakeLists.txt              # Must include rosidl_generate_interfaces() for msg
└── package.xml                 # Must declare rosidl_default_generators dependency
```

## File Explanations

### `msg/CustomMsg.msg`
```
string description
int32 value
```
Defines two fields:
- `description` — a text label (string)
- `value` — a counter or numeric payload (int32)

> After building, this auto-generates Python class `demo_custom_msg.msg.CustomMsg`.

### `custom_msg_publisher.py`
- Node name: `custom_msg_publisher`
- Creates a publisher on topic `/custom_topic` with type `CustomMsg`
- Timer fires every **1 second** and publishes:
  - `description = "Hello from Custom Message Publisher!"`
  - `value = counter` (increments each call)
- Logs each published message

### `custom_msg_subscriber.py`
- Node name: `custom_msg_subscriber`
- Subscribes to `/custom_topic`
- On each message, prints `description` and `value` to the terminal

## How to Build

```bash
cd ~/arjuna2_ws
source /opt/ros/humble/setup.bash
colcon build --packages-select demo_custom_msg --symlink-install
source install/setup.bash
```

> ⚠️ **Always rebuild and re-source** after changing `.msg` files. The build step generates the Python classes.

## How to Run

Open **2 terminals**:

```bash
# Terminal 1 — Publisher
source ~/arjuna2_ws/install/setup.bash
ros2 run demo_custom_msg custom_msg_publisher

# Terminal 2 — Subscriber
source ~/arjuna2_ws/install/setup.bash
ros2 run demo_custom_msg custom_msg_subscriber
```

### Expected Output

**Publisher:**
```
[INFO]: Published custom message: description='Hello from Custom Message Publisher!', value=0
[INFO]: Published custom message: description='Hello from Custom Message Publisher!', value=1
```

**Subscriber:**
```
[INFO]: Received: description='Hello from Custom Message Publisher!', value=0
[INFO]: Received: description='Hello from Custom Message Publisher!', value=1
```

### Inspect the Custom Message

```bash
# View the generated message type
ros2 interface show demo_custom_msg/msg/CustomMsg

# Echo topic manually
ros2 topic echo /custom_topic
```

## How to Create Your Own Message

1. Add a `.msg` file in the `msg/` folder with your field definitions
2. Update `CMakeLists.txt`:
   ```cmake
   rosidl_generate_interfaces(${PROJECT_NAME}
     "msg/YourMessage.msg"
   )
   ```
3. Update `package.xml` with `rosidl_default_generators` as a build dependency
4. `colcon build` to generate the Python/C++ bindings
5. Import in Python: `from your_package.msg import YourMessage`

## Key ROS 2 Concepts Demonstrated

| Concept | Where Used |
|---------|-----------|
| Custom `.msg` file definition | `msg/CustomMsg.msg` |
| `rosidl_generate_interfaces` | `CMakeLists.txt` |
| Import `from package.msg import Type` | Both scripts |
| Create and populate custom message | `custom_msg_publisher.py` |

## License
MIT — Newrro Tech
