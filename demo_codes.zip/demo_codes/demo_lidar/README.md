# demo_lidar — LIDAR Subscriber Demo

Demonstrates how to subscribe to **LIDAR scan data** from the RPLIDAR and divide the field of view into named directional zones for obstacle detection.

## 🔑 Concept

> A 2D LIDAR returns a circular array of distance measurements (called `ranges[]`). This demo shows how to divide those 360° readings into meaningful zones (front, left, right, etc.) and extract the minimum distance in each zone — exactly what obstacle avoidance algorithms need.

```
RPLIDAR → /scan (sensor_msgs/LaserScan) → demo_lidar_subscriber → Logs zone distances
```

## Package Structure

```
demo_lidar/
├── demo_lidar/
│   ├── __init__.py
│   └── lidar_sub.py    # Subscribes /scan, divides into zones, logs distances
├── scripts/
│   └── (utility scripts)
├── launch/
│   └── (launch files)
├── resource/
├── package.xml
├── setup.cfg
└── setup.py
```

## File Explanation

### `lidar_sub.py` — `LidarSubscriber` node

**How it works:**

1. Subscribes to `/scan` topic (`sensor_msgs/LaserScan`)
2. In `listener_callback`, receives the full 360° scan
3. Defines a helper `get_region_min(start_deg, end_deg)`:
   - Converts degree range → array index range using `n = len(msg.ranges)`
   - Handles wrap-around (e.g. front spans 330°–30°)
   - Filters invalid readings (`0`, `inf`, out-of-range values)
   - Returns the **minimum valid distance** in that region (or 10.0 m if none)
4. Computes 6 directional zones:

| Zone | Degrees | Description |
|------|---------|-------------|
| `front_L` | 0° – 30° | Front-left arc |
| `fleft` | 30° – 75° | Forward-left |
| `left` | 75° – 135° | Pure left |
| `right` | 225° – 285° | Pure right |
| `fright` | 285° – 330° | Forward-right |
| `front_R` | 330° – 360° | Front-right arc |

5. Logs all zone distances on one line per scan

### `sensor_msgs/LaserScan` Message Fields Used

| Field | Description |
|-------|-------------|
| `ranges[]` | Array of distance values (m), one per angular step |
| `range_min` | Minimum valid range (e.g. 0.15 m) |
| `range_max` | Maximum valid range (e.g. 12.0 m) |
| `angle_increment` | Radians per array index |

## How to Build

```bash
cd ~/arjuna2_ws
source /opt/ros/humble/setup.bash
colcon build --packages-select demo_lidar --symlink-install
source install/setup.bash
```

## How to Run

**Requires the RPLIDAR to be running first.**

```bash
# Terminal 1 — Start LIDAR driver
source ~/arjuna2_ws/install/setup.bash
ros2 launch sllidar_ros2 sllidar_a1_launch.py serial_port:=/dev/ttyUSB1

# Terminal 2 — Start LIDAR subscriber demo
source ~/arjuna2_ws/install/setup.bash
ros2 run demo_lidar lidar_sub
```

### Test Without Hardware (Simulate)

```bash
# Publish fake scan data for testing
ros2 topic pub /scan sensor_msgs/msg/LaserScan \
  "{header: {frame_id: 'laser'}, angle_min: 0.0, angle_max: 6.28, angle_increment: 0.0174, \
   range_min: 0.1, range_max: 12.0, ranges: $(python3 -c 'print([1.5]*360)')}"
```

### Expected Output

```
[INFO] Regions -> front_L: 0.82m | fleft: 1.23m | left: 2.10m | right: 1.87m | fright: 0.95m | front_R: 0.79m
```

### Inspect the `/scan` Topic

```bash
# Echo raw scan
ros2 topic echo /scan

# Check publish rate (should be ~10 Hz for A1)
ros2 topic hz /scan

# View in RViz
ros2 launch sllidar_ros2 view_sllidar_a1_launch.py serial_port:=/dev/ttyUSB1
```

## Connection to Navigation

The zone-based minimum distances from this demo are used directly in:
- `obstacle_avoidance.py` — reactive stop/turn logic
- `bug0/1/2.py` — wall-following algorithms
- `apf.py` — artificial potential field repulsion

## Key ROS 2 Concepts Demonstrated

| Concept | Where Used |
|---------|-----------|
| Subscribe to `sensor_msgs/LaserScan` | `lidar_sub.py` |
| Process `ranges[]` array | `get_region_min()` |
| Filter invalid float values (`inf`, `nan`, `0`) | `get_region_min()` |
| Angular index mapping | Degree-to-index conversion |

## License
MIT — Newrro Tech
