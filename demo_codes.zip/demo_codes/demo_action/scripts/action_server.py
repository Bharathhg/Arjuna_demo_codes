#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from rclpy.action import ActionServer
from demo_action.action import CustomAction
import time

class FibonacciActionServer(Node):
    def __init__(self):
        super().__init__('fibonacci_action_server')
        self._action_server = ActionServer(
            self,
            CustomAction,
            'fibonacci',
            self.execute_callback
        )
        self.get_logger().info("Fibonacci Action Server is running...")

    def execute_callback(self, goal_handle):
        self.get_logger().info(f"Executing goal: order={goal_handle.request.order}...")
        
        feedback_msg = CustomAction.Feedback()
        feedback_msg.partial_sequence = [0, 1]
        
        for i in range(1, goal_handle.request.order):
            feedback_msg.partial_sequence.append(
                feedback_msg.partial_sequence[i] + feedback_msg.partial_sequence[i-1]
            )
            self.get_logger().info(f"Publishing feedback: {feedback_msg.partial_sequence}")
            goal_handle.publish_feedback(feedback_msg)
            time.sleep(0.5)  # Simulate computing time
            
        goal_handle.succeed()
        
        result = CustomAction.Result()
        result.sequence = feedback_msg.partial_sequence
        self.get_logger().info(f"Goal succeeded! Sending result: {result.sequence}")
        return result

def main(args=None):
    rclpy.init(args=args)
    node = FibonacciActionServer()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
