#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient
from demo_action.action import CustomAction
import sys

class FibonacciActionClient(Node):
    def __init__(self):
        super().__init__('fibonacci_action_client')
        self._action_client = ActionClient(self, CustomAction, 'fibonacci')

    def send_goal(self, order):
        goal_msg = CustomAction.Goal()
        goal_msg.order = order

        self.get_logger().info(f"Waiting for action server 'fibonacci'...")
        self._action_client.wait_for_server()

        self.get_logger().info(f"Sending goal order={order}...")
        self._send_goal_future = self._action_client.send_goal_async(
            goal_msg,
            feedback_callback=self.feedback_callback
        )
        self._send_goal_future.add_done_callback(self.goal_response_callback)

    def goal_response_callback(self, future):
        goal_handle = future.result()
        if not goal_handle.accepted:
            self.get_logger().error("Goal rejected.")
            return

        self.get_logger().info("Goal accepted by server, waiting for result...")
        self._get_result_future = goal_handle.get_result_async()
        self._get_result_future.add_done_callback(self.get_result_callback)

    def get_result_callback(self, future):
        result = future.result().result
        self.get_logger().info(f"Action result: {result.sequence}")
        rclpy.shutdown()

    def feedback_callback(self, feedback_msg):
        feedback = feedback_msg.feedback
        self.get_logger().info(f"Received feedback: {feedback.partial_sequence}")

def main(args=None):
    rclpy.init(args=args)
    node = FibonacciActionClient()
    
    order = int(sys.argv[1]) if len(sys.argv) > 1 else 6
    node.send_goal(order)
    
    try:
        rclpy.spin(node)
    except SystemExit:
        pass
    except KeyboardInterrupt:
        pass

if __name__ == '__main__':
    main()
