# demo_action — Action Server / Client Demo

Demonstrates ROS 2 **Actions** — long-running tasks with goal, feedback, and result.

## 🔑 Concept

> **Actions** are like services but for **long-running tasks**. The client sends a **goal**, the server streams **feedback** while working, and finally sends a **result**. The client can also cancel the goal mid-execution.

```
Client ──► [Goal: order=6] ─────────────────────────► Server
       ◄── [Feedback: [0,1]] ◄─────────────────────────
       ◄── [Feedback: [0,1,1]] ◄──────────────────────
       ◄── [Feedback: [0,1,1,2,3,5]] ◄────────────────
       ◄── [Result: [0,1,1,2,3,5,8]] ◄───────────────
```

This example computes the **Fibonacci sequence** up to order N.

## Package Structure

```
demo_action/
├── action/
│   └── CustomAction.action     # Action definition: goal, feedback, result
├── scripts/
│   ├── action_server.py        # Fibonacci server — computes & streams progress
│   └── action_client.py        # Fibonacci client — sends goal, prints feedback
├── include/
├── src/
├── CMakeLists.txt
└── package.xml
```

## File Explanations

### `action/CustomAction.action`
Defines the three-part action interface:
```
# GOAL — sent by client
int32 order
---
# RESULT — sent when done
int32[] sequence
---
# FEEDBACK — sent during execution
int32[] partial_sequence
```

### `action_server.py`
- Node name: `fibonacci_action_server`
- Registers an `ActionServer` on the action name `fibonacci`
- `execute_callback` runs when a goal is received:
  - Starts with `[0, 1]`
  - Iteratively extends the Fibonacci sequence up to `order` length
  - Calls `goal_handle.publish_feedback(...)` every 0.5 seconds so the client sees progress
  - Calls `goal_handle.succeed()` when done, returns the full sequence as the result

### `action_client.py`
- Node name: `fibonacci_action_client`
- Reads the order from command-line argument (default: 6)
- Waits for the server, sends the goal asynchronously
- `feedback_callback` — prints partial Fibonacci list as it arrives
- `get_result_callback` — prints final sequence and shuts down

## How to Build

```bash
cd ~/arjuna2_ws
source /opt/ros/humble/setup.bash
colcon build --packages-select demo_action --symlink-install
source install/setup.bash
```

## How to Run

Open **2 terminals**:

```bash
# Terminal 1 — Start the Action Server
source ~/arjuna2_ws/install/setup.bash
ros2 run demo_action action_server

# Terminal 2 — Run the Client (compute Fibonacci up to order 8)
source ~/arjuna2_ws/install/setup.bash
ros2 run demo_action action_client 8
```

### Expected Output

**Server terminal:**
```
[INFO] Fibonacci Action Server is running...
[INFO] Executing goal: order=8...
[INFO] Publishing feedback: [0, 1, 1]
[INFO] Publishing feedback: [0, 1, 1, 2]
...
[INFO] Goal succeeded!
```

**Client terminal:**
```
[INFO] Sending goal order=8...
[INFO] Received feedback: [0, 1]
[INFO] Received feedback: [0, 1, 1]
...
[INFO] Action result: [0, 1, 1, 2, 3, 5, 8, 13]
```

### Monitor Actions from CLI (Optional)

```bash
# List all action servers
ros2 action list

# Get info about an action
ros2 action info /fibonacci

# Send a goal manually
ros2 action send_goal /fibonacci demo_action/action/CustomAction "{order: 5}" --feedback
```

## Key ROS 2 Concepts Demonstrated

| Concept | Where Used |
|---------|-----------|
| `ActionServer(node, type, name, callback)` | `action_server.py` |
| `ActionClient(node, type, name)` | `action_client.py` |
| `goal_handle.publish_feedback(msg)` | `action_server.py` |
| `goal_handle.succeed()` | `action_server.py` |
| `send_goal_async(goal, feedback_callback)` | `action_client.py` |
| Custom `.action` interface | `action/CustomAction.action` |

## When to Use Actions vs Services

| Scenario | Use |
|----------|-----|
| Short task, needs a direct response | Service |
| Long task, needs progress updates | **Action** |
| Fire-and-forget data stream | Topic |

## License
MIT — Newrro Tech
