# demo_imu — IMU BNO055 Publisher / Subscriber Demo

Demonstrates how to read data from the **Bosch BNO055** 9-DOF IMU over **I²C** and publish it as a standard ROS 2 `sensor_msgs/Imu` message.

## 🔑 Concept

> The BNO055 is a 9-axis IMU (Accelerometer + Gyroscope + Magnetometer) with an onboard sensor fusion processor. It outputs **quaternion orientation**, **angular velocity**, and **linear acceleration** directly. This demo reads all three over I²C and publishes them at 20 Hz.

## Hardware

| Component | Details |
|-----------|---------|
| Sensor | Bosch BNO055 |
| Interface | I²C |
| I²C Bus | Bus 1 (`/dev/i2c-1`) |
| I²C Address | `0x28` (default) |
| Mode | IMU Mode (`0x08`) |

## Package Structure

```
demo_imu/
├── demo_imu/
│   ├── __init__.py
│   ├── imu_pub.py         # Reads BNO055 over I²C → publishes /imu/data at 20Hz
│   └── imu_sub.py         # Subscribes /imu/data → prints orientation
├── scripts/
│   └── detect_sensor.py   # Utility: scans I²C bus for connected devices
├── launch/
│   └── (launch files)
├── resource/
├── package.xml
├── setup.cfg
└── setup.py
```

## File Explanations

### `imu_pub.py` — `BNO055Publisher` node

**How it works:**
1. Opens I²C bus (`smbus2.SMBus(1)`)
2. Sets BNO055 to **IMU Mode** (register `0x3D` ← `0x08`)
3. Creates a 20Hz timer (every 0.05 s)
4. Each timer tick:
   - Reads **Quaternion** from register `0x20` (4 × int16) → normalized to `[-1, 1]` by dividing by 16384
   - Reads **Gyroscope** from register `0x14` (3 × int16) → converted from dps to rad/s
   - Reads **Linear Acceleration** from register `0x28` (3 × int16) → converted from mg to m/s²
5. Publishes `sensor_msgs/Imu` on `/imu/data`

**Register addresses used:**

| Register | Data | Conversion |
|----------|------|------------|
| `0x3D` | Operation mode | Write `0x08` for IMU mode |
| `0x20` | Quaternion W,X,Y,Z | ÷ 16384 → float |
| `0x14` | Gyro X,Y,Z | ÷ 16 → dps, × π/180 → rad/s |
| `0x28` | Linear Accel X,Y,Z | ÷ 100 → m/s² |

### `imu_sub.py` — IMU Subscriber

- Subscribes to `/imu/data`
- Prints orientation (quaternion), angular velocity, and linear acceleration each time data arrives

### `scripts/detect_sensor.py`

Utility script that scans the I²C bus to verify the BNO055 is detected at address `0x28`:
```bash
python3 detect_sensor.py
```

## How to Build

```bash
cd ~/arjuna2_ws
source /opt/ros/humble/setup.bash
colcon build --packages-select demo_imu --symlink-install
source install/setup.bash
```

## How to Run

### Prerequisites

```bash
# Install smbus2
pip3 install smbus2

# Enable I²C on Jetson Nano / Raspberry Pi
sudo usermod -aG i2c $USER
sudo chmod 666 /dev/i2c-1

# Verify BNO055 is detected
i2cdetect -y 1   # Should show 0x28
```

```bash
# Terminal 1 — Publisher (requires BNO055 hardware)
source ~/arjuna2_ws/install/setup.bash
ros2 run demo_imu imu_pub

# Terminal 2 — Subscriber
source ~/arjuna2_ws/install/setup.bash
ros2 run demo_imu imu_sub
```

### Expected Output (Publisher)
```
[INFO] [demo_imu_publisher]: BNO055 Initialized in IMU Mode
```
> Data is published silently at 20Hz. Use the subscriber or `ros2 topic echo` to view it.

### View IMU Data

```bash
# Echo the full IMU message
ros2 topic echo /imu/data

# View publish rate
ros2 topic hz /imu/data
```

## Published Message: `sensor_msgs/Imu`

```
header:
  frame_id: "imu_link"
orientation:        # quaternion (x, y, z, w)
angular_velocity:   # rad/s (x, y, z)
linear_acceleration: # m/s² (x, y, z)
```

## Troubleshooting

| Problem | Solution |
|---------|---------|
| `Failed to initialize BNO055` | Check I²C wiring; run `i2cdetect -y 1` |
| Wrong address | Change `self.ADDR = 0x28` to `0x29` (alternative BNO055 address) |
| Bus 0 vs Bus 1 | Jetson Nano uses Bus 1; change `SMBus(1)` accordingly |

## License
MIT — Newrro Tech
