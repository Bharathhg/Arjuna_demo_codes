from setuptools import find_packages, setup

package_name = 'demo_ultrasonic_pyserial'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='hacker',
    maintainer_email='hacker@todo.todo',
    description='Demo package for Ultrasonic sensors using PySerial',
    license='Apache-2.0',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
        'console_scripts': [
            'ultrasonic_serial_pub = demo_ultrasonic_pyserial.ultrasonic_serial_pub:main',
            'ultrasonic_serial_sub = demo_ultrasonic_pyserial.ultrasonic_serial_sub:main'
        ],
    },
)
