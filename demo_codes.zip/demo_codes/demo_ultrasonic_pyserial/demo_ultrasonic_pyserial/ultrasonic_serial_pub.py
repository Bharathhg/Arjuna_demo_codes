#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Range
import serial
import random

class UltrasonicSerialPublisher(Node):
    def __init__(self):
        super().__init__('demo_ultrasonic_serial_publisher')
        
        # Declare parameters for Serial Port and Baudrate
        self.declare_parameter('port', '/dev/ttyUSB0')
        self.declare_parameter('baudrate', 115200)
        
        self.port = self.get_parameter('port').get_parameter_value().string_value
        self.baudrate = self.get_parameter('baudrate').get_parameter_value().integer_value
        
        # Publishers for Left and Right sensors
        self.pub_left = self.create_publisher(Range, 'left_ultrasonic', 10)
        self.pub_right = self.create_publisher(Range, 'right_ultrasonic', 10)
        
        # Initialize serial connection
        self.get_logger().info(f"Connecting to serial port: {self.port} at {self.baudrate} baud...")
        try:
            self.ser = serial.Serial(self.port, self.baudrate, timeout=0.1)
            self.ser.reset_input_buffer()
            self.get_logger().info("Serial connection established successfully.")
            self.serial_connected = True
        except Exception as e:
            self.get_logger().error(f"Failed to open serial port {self.port}: {e}. Running in Mock mode.")
            self.serial_connected = False
            
        # 10Hz reading loop using ROS 2 Timer
        self.timer = self.create_timer(0.1, self.read_and_publish)

    def read_and_publish(self):
        if not self.serial_connected:
            # Mock mode: publish simulated random distance values between 0.2m and 2.0m
            d1_m = random.uniform(0.2, 2.0)
            d2_m = random.uniform(0.2, 2.0)
            self.pub_left.publish(self.create_range_msg('ultrasonic_left', d1_m))
            self.pub_right.publish(self.create_range_msg('ultrasonic_right', d2_m))
            return
            
        try:
            if self.ser.in_waiting > 0:
                line = self.ser.readline().decode('utf-8', errors='ignore').strip()
                if not line:
                    return
                
                # Arduino prints "distance1,distance2" (e.g. "23.5,42.1")
                parts = line.split(',')
                if len(parts) == 2:
                    try:
                        d1 = float(parts[0])
                        d2 = float(parts[1])
                        
                        # Convert cm to meters
                        d1_m = d1 / 100.0 if d1 > 0 else -1.0
                        d2_m = d2 / 100.0 if d2 > 0 else -1.0
                        
                        # Publish valid Left readings (d1_m >= 0)
                        if d1_m >= 0:
                            self.pub_left.publish(self.create_range_msg('ultrasonic_left', d1_m))
                        # Publish valid Right readings (d2_m >= 0)
                        if d2_m >= 0:
                            self.pub_right.publish(self.create_range_msg('ultrasonic_right', d2_m))
                            
                    except ValueError:
                        self.get_logger().warn(f"Failed to parse serial line: '{line}'")
        except Exception as e:
            self.get_logger().error(f"Serial read error: {e}")

    def create_range_msg(self, frame_id, distance_m):
        msg = Range()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = frame_id
        msg.radiation_type = Range.ULTRASOUND
        msg.field_of_view = 0.523  # 30 degrees
        msg.min_range = 0.02
        msg.max_range = 4.0        # HC-SR04 max range is around 4 meters
        msg.range = float(distance_m)
        return msg

def main(args=None):
    rclpy.init(args=args)
    node = UltrasonicSerialPublisher()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        if rclpy.ok():
            if hasattr(node, 'ser') and node.ser:
                node.ser.close()
            node.destroy_node()
            rclpy.shutdown()

if __name__ == '__main__':
    main()
