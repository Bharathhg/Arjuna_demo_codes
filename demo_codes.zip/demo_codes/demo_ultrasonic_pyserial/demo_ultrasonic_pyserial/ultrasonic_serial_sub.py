#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Range

class UltrasonicSerialSubscriber(Node):
    def __init__(self):
        super().__init__('demo_ultrasonic_serial_subscriber')
        
        # Subscriptions to the Left and Right topics
        self.sub_left = self.create_subscription(
            Range,
            'left_ultrasonic',
            self.left_callback,
            10
        )
        
        self.sub_right = self.create_subscription(
            Range,
            'right_ultrasonic',
            self.right_callback,
            10
        )
        
        self.latest_left = -1.0
        self.latest_right = -1.0
        
        self.get_logger().info('Ultrasonic Serial Subscriber Node Started')
        self.timer = self.create_timer(0.5, self.print_status)

    def left_callback(self, msg):
        self.latest_left = msg.range

    def right_callback(self, msg):
        self.latest_right = msg.range

    def print_status(self):
        left_str = f"{self.latest_left:.2f}m" if self.latest_left >= 0 else "N/A"
        right_str = f"{self.latest_right:.2f}m" if self.latest_right >= 0 else "N/A"
        self.get_logger().info(
            f'Distances -> Left: {left_str} | Right: {right_str}'
        )

def main(args=None):
    rclpy.init(args=args)
    node = UltrasonicSerialSubscriber()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
