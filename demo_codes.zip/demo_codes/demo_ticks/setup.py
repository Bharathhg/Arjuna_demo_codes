from setuptools import find_packages, setup
import os
from glob import glob

package_name = 'demo_ticks'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'launch'), glob('launch/*.launch.py')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='hacker',
    maintainer_email='hacker@todo.todo',
    description='Demo wheel ticks publisher and subscriber simulation',
    license='Apache-2.0',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
        'console_scripts': [
            'demo_ticks_pub = demo_ticks.demo_ticks_pub:main',
            'demo_ticks_sub = demo_ticks.demo_ticks_sub:main',
        ],
    },
)
