# demo_ticks — Encoder Ticks Publisher / Subscriber Demo

Demonstrates how **wheel encoder ticks** are simulated, published, and subscribed to in ROS 2 — the foundation of wheel odometry.

## 🔑 Concept

> Real robots use **rotary encoders** attached to wheel axles to count how many "ticks" (pulses) the wheel has turned. By knowing the **ticks per meter** of your wheel, you can integrate these counts to estimate how far the robot has travelled — this is called **wheel odometry**.

This demo **simulates** encoder ticks without real hardware, making it safe to test the odometry pipeline on any machine.

```
DemoTicksPublisher
  ├── /cmd_vel    (Twist)  ← Simulated trajectory commands
  ├── /left_ticks (Int64)  ← Accumulated left encoder ticks
  └── /right_ticks(Int64)  ← Accumulated right encoder ticks
```

## Package Structure

```
demo_ticks/
├── demo_ticks/
│   ├── __init__.py
│   ├── demo_ticks_pub.py   # Simulates trajectory + publishes ticks at 10Hz
│   └── demo_ticks_sub.py   # Subscribes to tick topics and prints them
├── launch/
│   └── (launch files)
├── resource/
├── package.xml
├── setup.cfg
└── setup.py
```

## File Explanations

### `demo_ticks_pub.py` — `DemoTicksPublisher`

**Key parameters:**

| Parameter | Value | Description |
|-----------|-------|-------------|
| `WHEEL_BASE` | `0.28 m` | Distance between left and right wheels |
| `TICKS_PER_METER` | `20475.0` | Encoder resolution × gear ratio |
| Timer period | `0.1 s` | 10 Hz publish rate |

**Simulated motion pattern (repeating 10-second cycle):**

| Time | Motion | `linear.x` | `angular.z` |
|------|--------|------------|------------|
| 0 – 5 s | Drive straight forward | `0.2 m/s` | `0.0` |
| 5 – 10 s | Spin in place | `0.0` | `0.5 rad/s` |

**Kinematics used to compute per-wheel distances:**
```
v_right = linear_vel + (angular_vel × WHEEL_BASE) / 2
v_left  = linear_vel − (angular_vel × WHEEL_BASE) / 2

distance_right = v_right × dt
distance_left  = v_left  × dt

tick_increment = round(distance × TICKS_PER_METER)
total_ticks += tick_increment
```

**Published topics:**
- `/cmd_vel` — `geometry_msgs/Twist` — what the robot should do
- `/left_ticks` — `std_msgs/Int64` — cumulative left encoder count
- `/right_ticks` — `std_msgs/Int64` — cumulative right encoder count

### `demo_ticks_sub.py`

- Subscribes to `/left_ticks` and `/right_ticks`
- Prints each received count to the terminal
- Useful for verifying the publisher is working

## How to Build

```bash
cd ~/arjuna2_ws
source /opt/ros/humble/setup.bash
colcon build --packages-select demo_ticks --symlink-install
source install/setup.bash
```

## How to Run

```bash
# Terminal 1 — Tick Publisher (runs simulated trajectory)
source ~/arjuna2_ws/install/setup.bash
ros2 run demo_ticks demo_ticks_pub

# Terminal 2 — Tick Subscriber (reads and prints ticks)
source ~/arjuna2_ws/install/setup.bash
ros2 run demo_ticks demo_ticks_sub
```

### Expected Output (Publisher)

```
[INFO]: Publishing cmd_vel (lin=0.20, ang=0.00) | Ticks (Left=409, Right=409)
[INFO]: Publishing cmd_vel (lin=0.20, ang=0.00) | Ticks (Left=818, Right=818)
...
[INFO]: Publishing cmd_vel (lin=0.00, ang=0.50) | Ticks (Left=4090, Right=4160)
```

### Monitor Topics Manually

```bash
ros2 topic echo /left_ticks
ros2 topic echo /right_ticks
ros2 topic echo /cmd_vel
```

## How This Connects to Real Odometry

The `odometry` package (`ekf_data_pub.cpp`) reads these exact same topics:

```
/left_ticks  → integrate using TICKS_PER_METER → wheel_odom.x
/right_ticks → integrate using TICKS_PER_METER → wheel_odom.y
```

Then `robot_localization` fuses this with IMU data to publish `/robot_pose_ekf/odom_combined`.

## Calculating Your TICKS_PER_METER

```
TICKS_PER_METER = (Encoder CPR × Gear Ratio) / (π × Wheel Diameter)

Example:
  Encoder: 1000 CPR
  Gear ratio: 26:1  →  26000 ticks/revolution
  Wheel diameter: 0.065 m → circumference = π × 0.065 = 0.204 m
  TICKS_PER_METER = 26000 / 0.204 ≈ 127,450
```

> Arjuna uses STServo encoders with a different resolution — `20475` ticks/meter is calibrated for the specific wheel size.

## Key ROS 2 Concepts Demonstrated

| Concept | Where Used |
|---------|-----------|
| Multiple publishers in one node | `cmd_vel_pub`, `left_ticks_pub`, `right_ticks_pub` |
| `std_msgs/Int64` message | tick topics |
| Time-based trajectory generation | `timer_callback` |
| Differential drive integration | tick computation |

## License
MIT — Newrro Tech
