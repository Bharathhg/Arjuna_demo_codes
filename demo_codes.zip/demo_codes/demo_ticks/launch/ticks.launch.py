from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='demo_ticks',
            executable='demo_ticks_pub',
            name='demo_ticks_publisher',
            output='screen'
        ),
        Node(
            package='demo_ticks',
            executable='demo_ticks_sub',
            name='demo_ticks_subscriber',
            output='screen'
        )
    ])
