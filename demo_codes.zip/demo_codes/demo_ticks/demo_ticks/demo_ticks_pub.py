#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from std_msgs.msg import Int64
from geometry_msgs.msg import Twist

class DemoTicksPublisher(Node):
    def __init__(self):
        super().__init__('demo_ticks_publisher')
        
        # Publishers
        self.cmd_vel_pub = self.create_publisher(Twist, 'cmd_vel', 10)
        self.left_ticks_pub = self.create_publisher(Int64, 'left_ticks', 10)
        self.right_ticks_pub = self.create_publisher(Int64, 'right_ticks', 10)
        
        # Kinematic parameters (matching standard EKF odom node setup)
        self.WHEEL_BASE = 0.28  # Separation between wheels in meters
        self.TICKS_PER_METER = 20475.0  # Wheel encoder ticks per meter
        
        # Simulated tick accumulators
        self.total_left_ticks = 0
        self.total_right_ticks = 0
        
        self.start_time = self.get_clock().now()
        self.timer_period = 0.1  # seconds
        
        # 10Hz simulation and publishing loop
        self.timer = self.create_timer(self.timer_period, self.timer_callback)
        self.get_logger().info("Demo Ticks Publisher initialized.")

    def timer_callback(self):
        # 1. Generate a simulated trajectory command
        elapsed = (self.get_clock().now() - self.start_time).nanoseconds / 1e9
        cycle = elapsed % 10.0
        
        # Pattern: move forward for 5 seconds, spin for 5 seconds
        if cycle < 5.0:
            linear_vel = 0.2  # m/s
            angular_vel = 0.0  # rad/s
        else:
            linear_vel = 0.0  # m/s
            angular_vel = 0.5  # rad/s
            
        # 2. Publish Twist command
        cmd_msg = Twist()
        cmd_msg.linear.x = linear_vel
        cmd_msg.angular.z = angular_vel
        self.cmd_vel_pub.publish(cmd_msg)
        
        # 3. Integrate velocities to simulate left and right wheel distances
        v_right = linear_vel + (angular_vel * self.WHEEL_BASE) / 2.0
        v_left = linear_vel - (angular_vel * self.WHEEL_BASE) / 2.0
        
        d_right = v_right * self.timer_period
        d_left = v_left * self.timer_period
        
        # Convert distances to tick increments
        self.total_right_ticks += int(round(d_right * self.TICKS_PER_METER))
        self.total_left_ticks += int(round(d_left * self.TICKS_PER_METER))
        
        # 4. Publish simulated tick topics
        left_msg = Int64()
        left_msg.data = self.total_left_ticks
        self.left_ticks_pub.publish(left_msg)
        
        right_msg = Int64()
        right_msg.data = self.total_right_ticks
        self.right_ticks_pub.publish(right_msg)
        
        self.get_logger().info(
            f"Publishing cmd_vel (lin={linear_vel:.2f}, ang={angular_vel:.2f}) | "
            f"Ticks (Left={self.total_left_ticks}, Right={self.total_right_ticks})"
        )

def main(args=None):
    rclpy.init(args=args)
    node = DemoTicksPublisher()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
