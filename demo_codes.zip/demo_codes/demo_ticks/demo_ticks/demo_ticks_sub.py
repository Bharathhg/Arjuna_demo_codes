#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from std_msgs.msg import Int64

class DemoTicksSubscriber(Node):
    def __init__(self):
        super().__init__('demo_ticks_subscriber')
        
        self.left_ticks_sub = self.create_subscription(
            Int64,
            'left_ticks',
            self.left_callback,
            10
        )
        self.right_ticks_sub = self.create_subscription(
            Int64,
            'right_ticks',
            self.right_callback,
            10
        )
        
        self.left_ticks = 0
        self.right_ticks = 0
        self.get_logger().info("Demo Ticks Subscriber initialized.")

    def left_callback(self, msg):
        self.left_ticks = msg.data
        self.display_ticks()

    def right_callback(self, msg):
        self.right_ticks = msg.data
        self.display_ticks()

    def display_ticks(self):
        self.get_logger().info(
            f"Received Ticks - Left: {self.left_ticks} | Right: {self.right_ticks}",
            throttle_duration_sec=1.0
        )

def main(args=None):
    rclpy.init(args=args)
    node = DemoTicksSubscriber()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
