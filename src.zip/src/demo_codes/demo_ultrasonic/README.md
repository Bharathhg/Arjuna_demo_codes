# Demo Ultrasonic Package

This package demonstrates how to interface with ultrasonic sensors (typically HC-SR04) via an I2C controller (address 0x08) using ROS 2.

## Contents
- `scripts/detect_sensor.py`: Python script to scan the I2C bus for the ultrasonic controller (address 0x08).
- `demo_ultrasonic/publisher_node.py`: ROS 2 node that reads distance data from the I2C bus and publishes `sensor_msgs/Range` messages for left and right sensors.
- `demo_ultrasonic/subscriber_node.py`: ROS 2 node that subscribes to both range topics and logs the current distances.
- `launch/demo.launch.py`: Launch file that starts both nodes.

## How to Detect the Sensor
Run the detection script:
```bash
./scripts/detect_sensor.py
```

## How to Run the Demo
1. Build the workspace:
   ```bash
   colcon build --packages-select demo_ultrasonic
   source install/setup.bash
   ```
2. Launch the demo:
   ```bash
   ros2 launch demo_ultrasonic demo.launch.py
   ```

## ROS 2 Interface
- **Publication**: 
  - `/ultrasonic/left` ([sensor_msgs/msg/Range](https://docs.ros2.org/latest/api/sensor_msgs/msg/Range.html))
  - `/ultrasonic/right` ([sensor_msgs/msg/Range](https://docs.ros2.org/latest/api/sensor_msgs/msg/Range.html))
- **Subscription**: `/ultrasonic/left`, `/ultrasonic/right`
