from setuptools import find_packages, setup

package_name = 'demo_ultrasonic'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/launch', ['launch/ultrasonic.launch.py']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='aurora',
    maintainer_email='aurora@todo.todo',
    description='Demo package for Ultrasonic sensors',
    license='Apache-2.0',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
        'console_scripts': [
            'ultrasonic_pub = demo_ultrasonic.ultrasonic_pub:main',
            'ultrasonic_sub = demo_ultrasonic.ultrasonic_sub:main'
        ],
    },
)
