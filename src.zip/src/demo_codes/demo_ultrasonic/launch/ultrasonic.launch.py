from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='demo_ultrasonic',
            executable='ultrasonic_pub',
            name='demo_ultrasonic_publisher',
            output='screen'
        ),
        Node(
            package='demo_ultrasonic',
            executable='ultrasonic_sub',
            name='demo_ultrasonic_subscriber',
            output='screen'
        )
    ])
