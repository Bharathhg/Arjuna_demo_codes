import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Range

class UltrasonicSubscriber(Node):

    def __init__(self):
        super().__init__('demo_ultrasonic_subscriber')
        
        self.sub_left = self.create_subscription(
            Range, '/ultrasonic/left', self.left_callback, 10
        )
        self.sub_right = self.create_subscription(
            Range, '/ultrasonic/right', self.right_callback, 10
        )
        
        self.latest_left = 0.0
        self.latest_right = 0.0
        
        self.get_logger().info('Ultrasonic Subscriber Node Started')
        self.timer = self.create_timer(0.5, self.print_status)

    def left_callback(self, msg):
        self.latest_left = msg.range

    def right_callback(self, msg):
        self.latest_right = msg.range

    def print_status(self):
        self.get_logger().info(
            f'Distances -> Left: {self.latest_left:.2f}m | Right: {self.latest_right:.2f}m'
        )

def main(args=None):
    rclpy.init(args=args)
    node = UltrasonicSubscriber()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
