#!/usr/bin/env python3
import os
import subprocess

def detect_ultrasonic():
    print("Searching for Ultrasonic Sensors (I2C Address 0x08)...")
    
    # Check for I2C bus 1
    if not os.path.exists("/dev/i2c-1"):
        print("[FAILURE] I2C bus 1 (/dev/i2c-1) not found.")
        return False
    
    try:
        output = subprocess.check_output("i2cdetect -y 1", shell=True).decode()
        if "08" in output:
            print("[SUCCESS] Ultrasonic Controller detected at I2C address 0x08")
            return True
    except Exception as e:
        print(f"[ERROR] i2cdetect failed: {e}")
    
    print("[FAILURE] No device found at I2C address 0x08")
    return False

if __name__ == "__main__":
    detect_ultrasonic()
