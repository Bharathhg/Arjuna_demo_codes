# Demo Motor Package (STS Servos)

This package demonstrates how to control STS-series smart servos via a USB-to-RS485/TTL adapter using ROS 2.

## Contents
- `scripts/detect_sensor.py`: Python script to check for secondary USB-Serial devices (Motor Driver).
- `demo_motor/publisher_node.py`: ROS 2 node that subscribes to `/cmd_vel` and sends speed commands to STS servos using the `STservo_sdk`.
- `demo_motor/subscriber_node.py`: ROS 2 node that monitors `/cmd_vel` and logs commanded speeds.
- `launch/demo.launch.py`: Launch file that starts the driver and feedback nodes.

## How to Detect the Hardware
Run the detection script:
```bash
./scripts/detect_sensor.py
```
It looks for devices at `/dev/ttyUSB1` or secondary serial paths.

## How to Run the Demo
1. Ensure the `STservo_sdk` is accessible (included in the `demo_motor` folder).
2. Build the workspace:
   ```bash
   colcon build --packages-select demo_motor
   source install/setup.bash
   ```
3. Launch the demo:
   ```bash
   ros2 launch demo_motor demo.launch.py
   ```

## ROS 2 Interface
- **Subscription**: `/cmd_vel` ([geometry_msgs/msg/Twist](https://docs.ros2.org/latest/api/geometry_msgs/msg/Twist.html))
- **Parameters**: `device_name` (default: `/dev/ttyUSB1`), `baudrate` (default: `1000000`)
