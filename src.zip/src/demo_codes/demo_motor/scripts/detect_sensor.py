#!/usr/bin/env python3
import os
import subprocess

def detect_motors():
    print("Searching for Motor Driver (USB-Serial)...")
    
    # Common ports for motor drivers (often CH340 or FTDI)
    # Checking /dev/serial/by-path/ for a second USB device (Lidar is usually first)
    try:
        if os.path.exists("/dev/serial/by-path/"):
            paths = os.listdir("/dev/serial/by-path/")
            if len(paths) >= 2:
                print(f"[SUCCESS] Found {len(paths)} serial devices. One of them is likely the Motor Driver.")
                for p in paths:
                    print(f" - Found device at: /dev/serial/by-path/{p}")
                return True
        
        # Check for ttyUSB1 which is common if Lidar is ttyUSB0
        if os.path.exists("/dev/ttyUSB1"):
            print("[SUCCESS] Found /dev/ttyUSB1. This is the common port for the Motor Driver.")
            return True
            
    except Exception as e:
        print(f"[ERROR] Detection failed: {e}")
    
    print("[FAILURE] No secondary USB-Serial device found. Check motor driver cable.")
    return False

if __name__ == "__main__":
    detect_motors()
