import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist

class MotorFeedbackSubscriber(Node):

    def __init__(self):
        super().__init__('demo_motor_feedback')
        self.subscription = self.create_subscription(
            Twist,
            '/cmd_vel',
            self.listener_callback,
            10)
        self.subscription  # prevent unused variable warning
        self.get_logger().info('Motor Control Feedback Monitoring Started')

    def listener_callback(self, msg):
        self.get_logger().info(
            f'Monitoring /cmd_vel -> Linear: {msg.linear.x:.2f} | Angular: {msg.angular.z:.2f}'
        )

def main(args=None):
    rclpy.init(args=args)
    node = MotorFeedbackSubscriber()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
