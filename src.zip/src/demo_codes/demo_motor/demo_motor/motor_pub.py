import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
import time
import os
import sys

# Add current directory to path to find STservo_sdk
sys.path.append(os.path.dirname(__file__))
from STservo_sdk import PortHandler, sts, COMM_SUCCESS

class MotorDriverNode(Node):

    def __init__(self):
        super().__init__('demo_motor_driver')
        
        # Parameters
        self.declare_parameter('device_name', '/dev/ttyACM0')
        self.device_name = self.get_parameter('device_name').get_parameter_value().string_value
        self.baudrate = 1000000
        
        # Hardware Constants
        self.wheel_sep = 0.30
        self.speed_scaling = 3000
        
        # Motor IDs (Reference: IDs 1,4 Left; 2,3 Right)
        self.left_ids = [1, 4]
        self.right_ids = [2, 3]
        
        # Command Heartbeat Tracking
        self.last_cmd_time = self.get_clock().now()
        self.left_speed = 0
        self.right_speed = 0
        
        # Initialize SDK
        self.portHandler = PortHandler(self.device_name)
        self.packetHandler = sts(self.portHandler)
        
        try:
            if self.portHandler.openPort():
                self.get_logger().info(f"Succeeded to open the port {self.device_name}")
            else:
                self.get_logger().error(f"Failed to open the port {self.device_name}")
                return
            
            if self.portHandler.setBaudRate(self.baudrate):
                self.get_logger().info(f"Succeeded to change the baudrate to {self.baudrate}")
            else:
                self.get_logger().error(f"Failed to change the baudrate to {self.baudrate}")
                return

            # Initialize all 4 motors
            for motor_id in self.left_ids + self.right_ids:
                # Set to Wheel Mode
                self.packetHandler.WheelMode(motor_id)
                # Enable Torque (Register 40)
                self.packetHandler.write1ByteTxRx(motor_id, 40, 1)
            
            self.get_logger().info("All motors initialized in Wheel Mode and Torque Enabled")

            # Main processing loop (10Hz)
            self.timer = self.create_timer(0.1, self.main_loop)
            
            # cmd_vel subscriber
            self.subscription = self.create_subscription(
                Twist,
                '/cmd_vel',
                self.cmd_vel_callback,
                10)
                
        except Exception as e:
            self.get_logger().error(f"Motor initialization error: {e}")

    def cmd_vel_callback(self, msg):
        linear_vel = msg.linear.x
        angular_vel = msg.angular.z
        
        # Update Heartbeat
        self.last_cmd_time = self.get_clock().now()
        
        # Differential drive kinematics
        r_vel = ((linear_vel * 2.0) + (angular_vel * self.wheel_sep)) / 2.0
        l_vel = ((linear_vel * 2.0) - (angular_vel * self.wheel_sep)) / 2.0
        
        # Scaling to motor units
        self.right_speed = int(r_vel * self.speed_scaling)
        self.left_speed = int(l_vel * self.speed_scaling)

    def main_loop(self):
        # Heartbeat check: stop if no command for 2.0s
        now = self.get_clock().now()
        time_diff = (now - self.last_cmd_time).nanoseconds / 1e9
        
        if time_diff > 2.0:
            if self.left_speed != 0 or self.right_speed != 0:
                self.get_logger().warn(f"No control command for {time_diff:.1f}s. Stopping motors for safety.")
                self.left_speed = 0
                self.right_speed = 0

        # Send speeds to motors using WriteSpec (efficient)
        try:
            # Left side (inverted)
            for lid in self.left_ids:
                self.packetHandler.WriteSpec(lid, -self.left_speed, 0)
            
            # Right side
            for rid in self.right_ids:
                self.packetHandler.WriteSpec(rid, self.right_speed, 0)
        except Exception as e:
            self.get_logger().warn(f"Motor write error: {e}")

    def stop_motors(self):
        self.get_logger().info("Stopping all motors for shutdown...")
        try:
            for motor_id in self.left_ids + self.right_ids:
                self.packetHandler.WriteSpec(motor_id, 0, 0)
            time.sleep(0.1)
        except:
            pass

    def __del__(self):
        self.stop_motors()
        if hasattr(self, 'portHandler') and self.portHandler:
            self.portHandler.closePort()

def main(args=None):
    rclpy.init(args=args)
    node = MotorDriverNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.stop_motors()
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
