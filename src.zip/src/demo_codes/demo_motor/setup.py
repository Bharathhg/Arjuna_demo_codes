from setuptools import find_packages, setup

package_name = 'demo_motor'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name, package_name + '.STservo_sdk'],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/launch', ['launch/motor.launch.py']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='aurora',
    maintainer_email='aurora@todo.todo',
    description='Demo package for STS Motor Driver',
    license='Apache-2.0',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
        'console_scripts': [
            'motor_pub = demo_motor.motor_pub:main',
            'motor_sub = demo_motor.motor_sub:main'
        ],
    },
)
