from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='demo_motor',
            executable='motor_pub',
            name='demo_motor_driver',
            output='screen'
        ),
        Node(
            package='demo_motor',
            executable='motor-sub',
            name='demo_motor_feedback',
            output='screen'
        )
    ])
