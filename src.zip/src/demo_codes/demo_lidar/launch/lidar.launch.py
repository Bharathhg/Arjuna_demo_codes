import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, DeclareLaunchArgument
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node
from launch.substitutions import LaunchConfiguration

def generate_launch_description():
    # 1. Path to the RPLidar driver launch file
    # We copied sllidar_ros2 to our workspace, so we can use its share directory
    # 1. Path to the RPLidar driver launch directory
    lidar_driver_dir = get_package_share_directory('sllidar_ros2')
    
    # 2. Declare Launch Arguments
    serial_port_arg = DeclareLaunchArgument(
        'serial_port',
        default_value='/dev/rplidar', # Restored to symlink after udev application
        description='Specifying usb port to connected lidar'
    )

    lidar_model_arg = DeclareLaunchArgument(
        'lidar_model',
        default_value='c1',
        description='Lidar model: c1 or a1'
    )

    # 3. Include Driver Launch based on model
    driver_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            lidar_driver_dir, '/launch/sllidar_', LaunchConfiguration('lidar_model'), '_launch.py'
        ]),
        launch_arguments={'serial_port': LaunchConfiguration('serial_port')}.items()
    )

    # 4. Our Demo Subscriber Node
    subscriber_node = Node(
        package='demo_lidar',
        executable='lidar_sub',
        name='demo_lidar_subscriber',
        output='screen'
    )

    return LaunchDescription([
        serial_port_arg,
        lidar_model_arg,
        driver_launch,
        subscriber_node
    ])
