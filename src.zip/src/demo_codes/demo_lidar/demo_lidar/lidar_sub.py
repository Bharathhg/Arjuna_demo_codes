import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan

class LidarSubscriber(Node):

    def __init__(self):
        super().__init__('demo_lidar_subscriber')
        self.subscription = self.create_subscription(
            LaserScan,
            '/scan',
            self.listener_callback,
            10)
        self.subscription  # prevent unused variable warning
        self.get_logger().info('Lidar Subscriber Node Started - Waiting for data...')

    def listener_callback(self, msg):
        # 1. Handle dynamic point counts
        n = len(msg.ranges)
        if n == 0:
            return

        def get_region_min(start_deg, end_deg):
            """Calculate min distance in a degree-based zone"""
            # Convert degrees to indices (assuming 0 is front)
            start_idx = int((start_deg / 360.0) * n)
            end_idx = int((end_deg / 360.0) * n)
            
            # Extract range subset
            if start_idx < end_idx:
                subset = msg.ranges[start_idx:end_idx]
            else:
                # Handle wrap-around for front_R
                subset = msg.ranges[start_idx:] + msg.ranges[:end_idx]
            
            # Filter valid points (between min/max range, ignore 0/inf)
            valid = [r for r in subset if msg.range_min < r < msg.range_max]
            return min(valid) if valid else 10.0 # Return 10.0m if no points

        # 2. Divide into regions (names matching arjuna_ws)
        regions = {
            'front_L' : get_region_min(0, 30),
            'fleft'   : get_region_min(30, 75),
            'left'    : get_region_min(75, 135),
            'right'   : get_region_min(225, 285),
            'fright'  : get_region_min(285, 330),
            'front_R' : get_region_min(330, 360)
        }

        # 3. Log results in one line for easy monitoring
        log_str = " | ".join([f"{k}: {v:.2f}m" for k, v in regions.items()])
        self.get_logger().info(f"Regions -> {log_str}")

def main(args=None):
    rclpy.init(args=args)
    lidar_subscriber = LidarSubscriber()
    rclpy.spin(lidar_subscriber)
    lidar_subscriber.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
