#!/usr/bin/env python3
import os
import subprocess

def detect_lidar():
    print("Searching for Lidar (RPLidar)...")
    
    # 1. Check for /dev/rplidar symlink (often created by udev rules)
    if os.path.exists("/dev/rplidar"):
        print(f"[SUCCESS] Lidar found at /dev/rplidar")
        return True
    
    # 2. Check for common USB Serial devices
    try:
        # Looking for Silicon Labs CP2102 which is common for RPLidar
        output = subprocess.check_output("lsusb", shell=True).decode()
        if "Silicon Labs" in output or "CP210x" in output:
            print("[SUCCESS] USB-Serial adapter (CP210x) detected. This is likely the Lidar.")
            
            # Try to find which ttyUSB it is
            ls_output = subprocess.check_output("ls -l /dev/serial/by-id/", shell=True).decode()
            for line in ls_output.split('\n'):
                if "Silicon_Labs" in line:
                    port = line.split('->')[-1].strip().split('/')[-1]
                    print(f"Lidar is likely mapped to /dev/{port}")
            return True
    except:
        pass

    print("[FAILURE] No RPLidar detected. Please check connection.")
    return False

if __name__ == "__main__":
    detect_lidar()
