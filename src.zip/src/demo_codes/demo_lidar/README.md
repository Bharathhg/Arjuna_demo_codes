# Demo Lidar Package

This package demonstrates how to interface with an RPLidar C1 sensor using ROS 2 Humble.

## Contents
- `scripts/detect_sensor.py`: Python script to detect the RPLidar hardware.
- `demo_lidar/subscriber_node.py`: ROS 2 node that subscribes to `/scan` and prints distance statistics.
- `launch/demo.launch.py`: Launch file that starts both the driver and the subscriber.

## How to Detect the Sensor
Run the detection script:
```bash
./scripts/detect_sensor.py
```
It checks for `/dev/rplidar` or a Silicon Labs CP2102 USB-Serial adapter.

## How to Run the Demo
1. Build the workspace:
   ```bash
   colcon build --packages-select demo_lidar sllidar_ros2
   source install/setup.bash
   ```
2. Launch the demo:
   ```bash
   ros2 launch demo_lidar demo.launch.py
   ```

## ROS 2 Interface
- **Subscription**: `/scan` ([sensor_msgs/msg/LaserScan](https://docs.ros2.org/latest/api/sensor_msgs/msg/LaserScan.html))
- **Parameters**: `serial_port` (default: `/dev/rplidar`)
