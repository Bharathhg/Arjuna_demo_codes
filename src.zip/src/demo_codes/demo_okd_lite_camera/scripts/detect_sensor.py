#!/usr/bin/env python3
import depthai as dai

def detect_oak_d():
    print("Searching for OAK-D Camera (DepthAI)...")
    
    # Get all available devices
    devices = dai.Device.getAllAvailableDevices()
    
    if not devices:
        print("[FAILURE] No OAK-D devices found. Check USB connection.")
        return False
    
    print(f"[SUCCESS] Found {len(devices)} OAK-D device(s):")
    for dev in devices:
        print(f" - MXID: {dev.getMxId()} | Name: {dev.name} | Platform: {dev.platform}")
    
    return True

if __name__ == "__main__":
    detect_oak_d()
