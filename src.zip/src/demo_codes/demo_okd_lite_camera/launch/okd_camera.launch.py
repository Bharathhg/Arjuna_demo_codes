from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        # Camera Nodes
        Node(
            package='demo_camera',
            executable='publisher_node',
            name='demo_camera_publisher',
            output='screen'
        ),
        Node(
            package='demo_camera',
            executable='subscriber_node',
            name='demo_camera_subscriber',
            output='screen'
        ),
        # Static Transform for RViz visualization
        # Mappings camera_optical_frame to base_link
        Node(
            package='tf2_ros',
            executable='static_transform_publisher',
            name='camera_base_link_broadcaster',
            arguments=['0', '0', '0.1', '0', '0', '0', 'base_link', 'camera_optical_frame']
        )
    ])
