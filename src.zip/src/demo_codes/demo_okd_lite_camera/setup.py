from setuptools import find_packages, setup

package_name = 'demo_okd_lite_camera'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/launch', ['launch/okd_camera.launch.py']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='aurora',
    maintainer_email='aurora@todo.todo',
    description='Demo package for OAK-D Lite camera',
    license='Apache-2.0',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
        'console_scripts': [
            'okd_camera_pub = demo_okd_lite_camera.okd_camera_pub:main',
            'okd_camera_sub = demo_okd_lite_camera.okd_camera_sub:main'
        ],
    },
)
