import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image, CameraInfo
import depthai as dai
import cv2
from cv_bridge import CvBridge

class CameraPublisher(Node):

    def __init__(self):
        super().__init__('demo_camera_publisher')
        
        # Publishers
        self.image_pub = self.create_publisher(Image, '/camera/image_raw', 10)
        self.depth_pub = self.create_publisher(Image, '/camera/depth/image_raw', 10)
        
        self.bridge = CvBridge()
        
        # Create pipeline
        self.pipeline = dai.Pipeline()

        # Define sources and outputs
        cam_rgb = self.pipeline.create(dai.node.ColorCamera)
        xout_rgb = self.pipeline.create(dai.node.XLinkOut)
        mono_left = self.pipeline.create(dai.node.MonoCamera)
        mono_right = self.pipeline.create(dai.node.MonoCamera)
        depth = self.pipeline.create(dai.node.StereoDepth)
        xout_depth = self.pipeline.create(dai.node.XLinkOut)

        xout_rgb.setStreamName("rgb")
        xout_depth.setStreamName("depth")

        # Properties
        cam_rgb.setPreviewSize(640, 480)
        cam_rgb.setInterleaved(False)
        cam_rgb.setColorOrder(dai.ColorCameraProperties.ColorOrder.BGR)
        cam_rgb.setResolution(dai.ColorCameraProperties.SensorResolution.THE_1080_P)
        cam_rgb.setFps(30)

        mono_left.setResolution(dai.MonoCameraProperties.SensorResolution.THE_400_P)
        mono_left.setBoardSocket(dai.CameraBoardSocket.LEFT)
        mono_right.setResolution(dai.MonoCameraProperties.SensorResolution.THE_400_P)
        mono_right.setBoardSocket(dai.CameraBoardSocket.RIGHT)

        depth.setDefaultProfilePreset(dai.node.StereoDepth.PresetMode.HIGH_DENSITY)
        depth.setSubpixel(True)

        # Linking
        cam_rgb.preview.link(xout_rgb.input)
        mono_left.out.link(depth.left)
        mono_right.out.link(depth.right)
        depth.depth.link(xout_depth.input)

        # Connect to device and start pipeline
        try:
            self.device = dai.Device(self.pipeline)
            self.get_logger().info("OAK-D Pipeline Started!")
            
            self.q_rgb = self.device.getOutputQueue(name="rgb", maxSize=4, blocking=False)
            self.q_depth = self.device.getOutputQueue(name="depth", maxSize=4, blocking=False)
            
            self.timer = self.create_timer(0.033, self.timer_callback) # ~30 FPS
        except Exception as e:
            self.get_logger().error(f"Failed to start OAK-D: {e}")
            self.device = None

    def timer_callback(self):
        if self.device is None:
            return

        in_rgb = self.q_rgb.tryGet()
        in_depth = self.q_depth.tryGet()

        now = self.get_clock().now().to_msg()

        if in_rgb is not None:
            frame = in_rgb.getCvFrame()
            msg = self.bridge.cv2_to_imgmsg(frame, encoding="bgr8")
            msg.header.stamp = now
            msg.header.frame_id = "camera_optical_frame"
            self.image_pub.publish(msg)

        if in_depth is not None:
            depth_frame = in_depth.getFrame()
            msg = self.bridge.cv2_to_imgmsg(depth_frame, encoding="16UC1")
            msg.header.stamp = now
            msg.header.frame_id = "camera_optical_frame"
            self.depth_pub.publish(msg)

    def __del__(self):
        if hasattr(self, 'device') and self.device:
            self.device.close()

def main(args=None):
    rclpy.init(args=args)
    node = CameraPublisher()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        if rclpy.ok():
            node.destroy_node()
            rclpy.shutdown()

if __name__ == '__main__':
    main()
