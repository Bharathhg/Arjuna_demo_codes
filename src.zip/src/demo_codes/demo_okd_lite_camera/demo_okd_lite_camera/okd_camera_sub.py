import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
import cv2
from cv_bridge import CvBridge

class CameraSubscriber(Node):

    def __init__(self):
        super().__init__('demo_camera_subscriber')
        self.bridge = CvBridge()
        self.subscription = self.create_subscription(
            Image,
            '/camera/image_raw',
            self.listener_callback,
            10)
        self.subscription  # prevent unused variable warning
        self.get_logger().info('Camera Subscriber Node Started - Waiting for images...')

    def listener_callback(self, msg):
        try:
            # Convert ROS Image to OpenCV image
            cv_image = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
            
            # Get image stats
            height, width, channels = cv_image.shape
            avg_color = cv_image.mean(axis=(0,1))
            
            self.get_logger().info(
                f'Received Frame: {width}x{height} | Avg BGR: {avg_color.astype(int)}'
            )
            
            # Note: In a real demo you'd use rviz2, but here we just log
        except Exception as e:
            self.get_logger().error(f'Error processing image: {e}')

def main(args=None):
    rclpy.init(args=args)
    camera_subscriber = CameraSubscriber()
    rclpy.spin(camera_subscriber)
    camera_subscriber.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
