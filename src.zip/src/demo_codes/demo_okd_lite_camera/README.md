# Demo Camera Package (OAK-D Lite)

This package demonstrates how to interface with an OAK-D Lite camera using DepthAI and ROS 2.

## Contents
- `scripts/detect_sensor.py`: Python script using `depthai` to detect connected OAK-D devices.
- `demo_camera/publisher_node.py`: ROS 2 node that starts an OAK-D pipeline (RGB + Depth) and publishes images.
- `demo_camera/subscriber_node.py`: ROS 2 node that subscribes to `/camera/image_raw` and logs frame info.
- `launch/demo.launch.py`: Launch file that starts both nodes.

## How to Detect the Sensor
Run the detection script:
```bash
./scripts/detect_sensor.py
```

## How to Run the Demo
1. Install dependencies:
   ```bash
   pip install depthai opencv-python
   ```
2. Build the workspace:
   ```bash
   colcon build --packages-select demo_camera
   source install/setup.bash
   ```
3. Launch the demo:
   ```bash
   ros2 launch demo_camera demo.launch.py
   ```

## ROS 2 Interface
- **Publication**: 
  - `/camera/image_raw` ([sensor_msgs/msg/Image](https://docs.ros2.org/latest/api/sensor_msgs/msg/Image.html)): RGB Preview
  - `/camera/depth/image_raw` ([sensor_msgs/msg/Image](https://docs.ros2.org/latest/api/sensor_msgs/msg/Image.html)): 16UC1 Depth Frame
- **Subscription**: `/camera/image_raw`
