#!/usr/bin/env python3
import os
import subprocess

def detect_bno055():
    print("Searching for BNO055 IMU (I2C)...")
    
    # Check for I2C bus 1
    if not os.path.exists("/dev/i2c-1"):
        print("[FAILURE] I2C bus 1 (/dev/i2c-1) not found. Enable I2C in raspi-config.")
        return False
    
    try:
        # Scan I2C bus 1 for address 0x28 (default BNO055 address)
        output = subprocess.check_output("i2cdetect -y 1", shell=True).decode()
        if "28" in output:
            print("[SUCCESS] BNO055 detected at I2C address 0x28")
            return True
        elif "29" in output:
            print("[SUCCESS] BNO055 detected at I2C address 0x29 (alternative)")
            return True
    except Exception as e:
        print(f"[ERROR] i2cdetect failed: {e}")
        print("Note: You might need to install i2c-tools: sudo apt install i2c-tools")
    
    print("[FAILURE] BNO055 not found on I2C bus 1 at address 0x28 or 0x29")
    return False

if __name__ == "__main__":
    detect_bno055()
