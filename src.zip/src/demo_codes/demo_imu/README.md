# Demo IMU Package (BNO055)

This package demonstrates how to interface with a Bosch BNO055 9-DOF IMU using I2C and ROS 2.

## Contents
- `scripts/detect_sensor.py`: Python script to scan the I2C bus for the BNO055 (address 0x28).
- `demo_imu/publisher_node.py`: ROS 2 node that reads orientation, gyro, and accel data from the sensor and publishes `sensor_msgs/Imu`.
- `demo_imu/subscriber_node.py`: ROS 2 node that subscribes to `/imu/data`, converts quaternions to Euler angles, and prints them.
- `launch/demo.launch.py`: Launch file that starts both nodes.

## How to Detect the Sensor
Run the detection script:
```bash
./scripts/detect_sensor.py
```
Ensure I2C is enabled and `i2c-tools` is installed.

## How to Run the Demo
1. Install dependencies:
   ```bash
   pip install smbus2
   ```
2. Build the workspace:
   ```bash
   colcon build --packages-select demo_imu
   source install/setup.bash
   ```
3. Launch the demo:
   ```bash
   ros2 launch demo_imu demo.launch.py
   ```

## ROS 2 Interface
- **Publication**: `/imu/data` ([sensor_msgs/msg/Imu](https://docs.ros2.org/latest/api/sensor_msgs/msg/Imu.html))
- **Subscription**: `/imu/data`
