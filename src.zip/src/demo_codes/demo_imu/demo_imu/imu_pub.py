import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Imu
import smbus2
import time
import math

class BNO055Publisher(Node):

    def __init__(self):
        super().__init__('demo_imu_publisher')
        self.publisher_ = self.create_publisher(Imu, '/imu/data', 10)
        
        # BNO055 I2C Address and Registers
        self.ADDR = 0x28
        self.OPR_MODE_ADDR = 0x3D
        self.IMU_MODE = 0x08
        self.QUAT_DATA_ADDR = 0x20
        self.GYRO_DATA_ADDR = 0x14
        self.ACCEL_DATA_ADDR = 0x28
        
        try:
            self.bus = smbus2.SMBus(1)
            # Set to IMU mode
            self.bus.write_byte_data(self.ADDR, self.OPR_MODE_ADDR, self.IMU_MODE)
            time.sleep(0.05)
            self.get_logger().info("BNO055 Initialized in IMU Mode")
            self.timer = self.create_timer(0.05, self.timer_callback) # 20Hz
        except Exception as e:
            self.get_logger().error(f"Failed to initialize BNO055: {e}")
            self.bus = None

    def read_i16_block(self, reg, count):
        data = self.bus.read_i2c_block_data(self.ADDR, reg, count*2)
        res = []
        for i in range(count):
            val = (data[i*2+1] << 8) | data[i*2]
            if val > 32767: val -= 65536
            res.append(val)
        return res

    def timer_callback(self):
        if self.bus is None: return
        
        try:
            msg = Imu()
            msg.header.stamp = self.get_clock().now().to_msg()
            msg.header.frame_id = 'imu_link'
            
            # Read Quaternions
            q = self.read_i16_block(self.QUAT_DATA_ADDR, 4)
            msg.orientation.w = q[0] / 16384.0
            msg.orientation.x = q[1] / 16384.0
            msg.orientation.y = q[2] / 16384.0
            msg.orientation.z = q[3] / 16384.0
            
            # Read Gyro (dps -> rad/s)
            g = self.read_i16_block(self.GYRO_DATA_ADDR, 3)
            d2r = math.pi / 180.0
            msg.angular_velocity.x = (g[0] / 16.0) * d2r
            msg.angular_velocity.y = (g[1] / 16.0) * d2r
            msg.angular_velocity.z = (g[2] / 16.0) * d2r
            
            # Read Linear Accel (mg -> m/s^2)
            a = self.read_i16_block(self.ACCEL_DATA_ADDR, 3)
            msg.linear_acceleration.x = a[0] / 100.0
            msg.linear_acceleration.y = a[1] / 100.0
            msg.linear_acceleration.z = a[2] / 100.0
            
            self.publisher_.publish(msg)
            
        except Exception as e:
            self.get_logger().warn(f"Read error: {e}")

def main(args=None):
    rclpy.init(args=args)
    node = BNO055Publisher()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
