from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='demo_imu',
            executable='imu_pub',
            name='demo_imu_publisher',
            output='screen'
        ),
        Node(
            package='demo_imu',
            executable='imu_sub',
            name='demo_imu_subscriber',
            output='screen'
        )
    ])
