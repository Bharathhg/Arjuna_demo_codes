from setuptools import find_packages, setup

package_name = 'demo_navigation'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/launch', [
            'launch/demo.launch.py',
            'launch/all_sensors.launch.py'
        ]),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='aurora',
    maintainer_email='aurora@todo.todo',
    description='Demo package for Autonomous Navigation',
    license='Apache-2.0',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
        'console_scripts': [
            'obstacle_avoidance = demo_navigation.obstacle_avoidance:main',
            'go_to_point = demo_navigation.go_to_point:main',
            'multi_point = demo_navigation.multi_point:main'
        ],
    },
)
