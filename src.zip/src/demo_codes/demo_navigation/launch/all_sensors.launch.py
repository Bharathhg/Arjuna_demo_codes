import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, LogInfo
from launch.launch_description_sources import PythonLaunchDescriptionSource

def generate_launch_description():
    # Get package directories
    try:
        pkg_camera = get_package_share_directory('demo_camera')
        pkg_imu = get_package_share_directory('demo_imu')
        pkg_lidar = get_package_share_directory('demo_lidar')
        pkg_motor = get_package_share_directory('demo_motor')
        pkg_ultrasonic = get_package_share_directory('demo_ultrasonic')
        pkg_navigation = get_package_share_directory('demo_navigation')
    except Exception as e:
        return LaunchDescription([
            LogInfo(msg=f"Error finding packages: {e}")
        ])

    return LaunchDescription([
        LogInfo(msg="Starting Master Robot Launch - Initializing all sensors and navigation..."),
        
        # 1. Camera System (OAK-D Lite)
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(os.path.join(pkg_camera, 'launch', 'demo.launch.py')),
        ),
        
        # 2. IMU System (BNO055)
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(os.path.join(pkg_imu, 'launch', 'demo.launch.py')),
        ),
        
        # 3. LIDAR System (RPLIDAR + Subscriber)
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(os.path.join(pkg_lidar, 'launch', 'demo.launch.py')),
        ),
        
        # 4. Ultrasonic System (HC-SR04)
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(os.path.join(pkg_ultrasonic, 'launch', 'demo.launch.py')),
        ),
        
        # 5. Motor Control System (STservo)
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(os.path.join(pkg_motor, 'launch', 'demo.launch.py')),
        ),
        
        # 6. Navigation System (Obstacle Avoidance Logic)
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(os.path.join(pkg_navigation, 'launch', 'demo.launch.py')),
        ),
        
        LogInfo(msg="All nodes launched. Check terminal output for sensor data feedback.")
    ])
