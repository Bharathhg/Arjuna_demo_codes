from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='demo_navigation',
            executable='obstacle_avoidance',
            name='demo_obstacle_avoidance',
            output='screen'
        )
    ])
