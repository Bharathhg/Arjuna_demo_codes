# Demo Navigation Package

This package demonstrates autonomous navigation capabilities, including obstacle avoidance and point-to-point movement, ported from the `arjuna` navigation stack.

## Contents
- `demo_navigation/obstacle_avoidance.py`: ROS 2 node that uses Lidar data (`/scan`) to steer the robot around obstacles by publishing to `/cmd_vel`.
- `demo_navigation/go_to_point.py`: ROS 2 node that moves the robot to a specific (x, y) coordinate.
- `demo_navigation/multi_point.py`: ROS 2 node that follows a sequence of waypoints.
- `launch/demo.launch.py`: Launch file for the obstacle avoidance demo.

## How to Run the Demo
1. Build the workspace:
   ```bash
   colcon build --packages-select demo_navigation
   source install/setup.bash
   ```
2. Start the Lidar and Motor drivers (of your choice).
3. Launch the obstacle avoidance:
   ```bash
   ros2 launch demo_navigation demo.launch.py
   ```

## ROS 2 Interface
- **Subscription**: `/scan` ([sensor_msgs/msg/LaserScan](https://docs.ros2.org/latest/api/sensor_msgs/msg/LaserScan.html))
- **Publication**: `/cmd_vel` ([geometry_msgs/msg/Twist](https://docs.ros2.org/latest/api/geometry_msgs/msg/Twist.html))
